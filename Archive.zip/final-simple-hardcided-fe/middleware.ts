import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  // Check if user is trying to access /test page
  if (request.nextUrl.pathname.startsWith('/test')) {
    const sessionToken = request.cookies.get('session_token')?.value

    // If no session token, redirect to home page for OTP verification
    if (!sessionToken) {
      return NextResponse.redirect(new URL('/', request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: '/test/:path*',
}
