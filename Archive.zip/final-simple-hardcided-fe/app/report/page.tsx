"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  IconFileTypePdf,
  IconAlertCircle,
  IconDownload,
  IconMail,
} from "@tabler/icons-react";
import { toast } from "sonner";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { testApi, type TestResultResponse } from "@/lib/api";

function ReportContent() {
  const searchParams = useSearchParams();
  const [email, setEmail] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [reportData, setReportData] = useState<TestResultResponse | null>(null);

  const formatTime = (seconds: number | null): string => {
    if (seconds === null) return "N/A";

    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
      return `${hours}h ${mins}m ${secs}s`;
    } else if (mins > 0) {
      return `${mins}m ${secs}s`;
    } else {
      return `${secs}s`;
    }
  };

  const fetchResult = async (emailToFetch?: string) => {
    const targetEmail = emailToFetch || email;

    if (!targetEmail) {
      toast.error("Please enter an email address");
      return;
    }

    setIsFetching(true);
    try {
      const data = await testApi.getResult(targetEmail);
      setReportData(data);
      toast.success("Test results fetched successfully!");
    } catch (error) {
      console.error("Fetch error:", error);
      toast.error(
        error instanceof Error ? error.message : "Failed to fetch test results"
      );
    } finally {
      setIsFetching(false);
    }
  };

  // Fetch data from URL parameter on mount
  useEffect(() => {
    const emailParam = searchParams.get("email");
    if (emailParam) {
      setEmail(emailParam);
      fetchResult(emailParam);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const generatePDF = () => {
    if (!reportData) {
      toast.error("Please fetch test results first");
      return;
    }

    setIsGenerating(true);

    try {
      const data = reportData;

      if (!data.success) {
        throw new Error("Invalid data: success is false");
      }

      // Create PDF
      const doc = new jsPDF();
      let yPos = 20;

      // Use system fonts (no custom font loading needed)
      // Title
      doc.setFontSize(20);
      doc.setFont("helvetica", "bold");
      doc.text("Test Report", 105, yPos, { align: "center" });
      yPos += 15;

      // Student Information
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("Student Information", 20, yPos);
      yPos += 8;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.text(`Name: ${data.student.name}`, 20, yPos);
      yPos += 6;
      doc.text(`Email: ${data.student.email}`, 20, yPos);
      yPos += 12;

      // Overall Performance
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("Overall Performance", 20, yPos);
      yPos += 8;

      const accuracy =
        data.session.total_questions_answered > 0
          ? (
              (data.session.score / data.session.total_questions_answered) *
              100
            ).toFixed(1)
          : "0";

      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.text(
        `Score: ${data.session.score} / ${data.session.total_questions_answered}`,
        20,
        yPos
      );
      yPos += 6;
      doc.text(`Accuracy: ${accuracy}%`, 20, yPos);
      yPos += 6;
      doc.text(
        `Total Time: ${formatTime(data.session.total_time_taken_seconds)}`,
        20,
        yPos
      );
      yPos += 6;
      doc.text(
        `Status: ${data.session.completed ? "Completed" : "Incomplete"}`,
        20,
        yPos
      );
      yPos += 15;

      // Section-wise Breakdown
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("Section-wise Performance", 20, yPos);
      yPos += 8;

      const sectionData = data.sections.map((section) => {
        const answeredQuestions = section.questions.filter(
          (q) => q.selected_answer !== null
        ).length;
        const correctAnswers = section.questions.filter(
          (q) => q.is_correct === true
        ).length;
        const sectionTime = section.questions.reduce(
          (sum, q) => sum + (q.time_taken_seconds || 0),
          0
        );
        const sectionAccuracy =
          answeredQuestions > 0
            ? ((correctAnswers / answeredQuestions) * 100).toFixed(1)
            : "0";

        return [
          section.name,
          `${correctAnswers} / ${answeredQuestions}`,
          `${sectionAccuracy}%`,
          formatTime(sectionTime),
        ];
      });

      autoTable(doc, {
        startY: yPos,
        head: [["Section", "Score", "Accuracy", "Time Taken"]],
        body: sectionData,
        theme: "grid",
        headStyles: {
          fillColor: [59, 130, 246],
          textColor: 255,
          fontStyle: "bold",
        },
        styles: { fontSize: 9 },
      });

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      yPos = (doc as any).lastAutoTable.finalY + 15;

      // Detailed Question-by-Question Results
      data.sections.forEach((section) => {
        // Check if we need a new page
        if (yPos > 250) {
          doc.addPage();
          yPos = 20;
        }

        doc.setFontSize(12);
        doc.setFont("helvetica", "bold");
        doc.text(`${section.name} - Detailed Results`, 20, yPos);
        yPos += 8;

        section.questions.forEach((question, qIndex) => {
          // Check if we need a new page for this question
          if (yPos > 240) {
            doc.addPage();
            yPos = 20;
          }

          // Question number and status indicator
          doc.setFontSize(10);
          doc.setFont("helvetica", "bold");

          let statusColor: [number, number, number] = [0, 0, 0];
          if (question.is_correct === true) {
            statusColor = [34, 197, 94]; // green
          } else if (question.is_correct === false) {
            statusColor = [239, 68, 68]; // red
          } else {
            statusColor = [156, 163, 175]; // gray
          }

          doc.setTextColor(...statusColor);
          doc.text(`Q${qIndex + 1}.`, 20, yPos);
          doc.setTextColor(0, 0, 0);

          // Question text
          doc.setFont("helvetica", "normal");
          doc.setFontSize(10);
          const questionLines = doc.splitTextToSize(question.question, 165);
          doc.text(questionLines, 30, yPos);
          yPos += questionLines.length * 5 + 4;

          // Options
          question.options.forEach((option, optIndex) => {
            const isCorrect = optIndex === question.correctAnswer;
            const isSelected = optIndex === question.selected_answer;

            let optionColor: [number, number, number] = [60, 60, 60]; // default dark gray

            if (isCorrect && isSelected) {
              optionColor = [34, 197, 94]; // green - correct answer selected
            } else if (isCorrect) {
              optionColor = [34, 197, 94]; // green - correct answer
            } else if (isSelected) {
              optionColor = [239, 68, 68]; // red - wrong answer selected
            }

            doc.setTextColor(...optionColor);
            doc.setFontSize(9);
            const optionText = `${String.fromCharCode(
              65 + optIndex
            )}. ${option}`;
            const optionLines = doc.splitTextToSize(optionText, 160);
            doc.text(optionLines, 30, yPos);
            yPos += optionLines.length * 4.5;
            doc.setTextColor(0, 0, 0);
          });

          // Time taken
          yPos += 2;
          doc.setFontSize(8);
          doc.setTextColor(120, 120, 120);
          doc.text(
            `Time: ${formatTime(question.time_taken_seconds)}`,
            30,
            yPos
          );
          doc.setTextColor(0, 0, 0);
          yPos += 10;
        });

        yPos += 5;
      });

      // Save PDF
      const fileName = `Test_Report_${data.student.name.replace(/\s+/g, "_")}_${
        new Date().toISOString().split("T")[0]
      }.pdf`;
      doc.save(fileName);

      toast.success("PDF generated successfully!");
    } catch (error) {
      console.error("PDF generation error:", error);
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to generate PDF. Please check your JSON input."
      );
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-muted/30 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <IconFileTypePdf className="h-6 w-6 text-primary" />
              <CardTitle className="text-2xl">Test Report</CardTitle>
            </div>
            <CardDescription>
              Enter student email to fetch test results and generate a PDF
              report
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Student Email</label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <IconMail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="student@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    onKeyDown={(e) => e.key === "Enter" && fetchResult()}
                  />
                </div>
                <Button onClick={() => fetchResult()} disabled={!email || isFetching}>
                  {isFetching ? "Fetching..." : "Fetch Results"}
                </Button>
              </div>
            </div>

            {reportData && (
              <Button
                size="lg"
                onClick={generatePDF}
                disabled={isGenerating}
                className="w-full"
              >
                <IconDownload className="mr-2 h-4 w-4" />
                {isGenerating ? "Generating PDF..." : "Download PDF Report"}
              </Button>
            )}

            {!reportData && (
              <Alert>
                <IconAlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Enter a student email address and click &quot;Fetch Results&quot; to
                  retrieve test data from the API.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Display Report Results */}
        {reportData && (
          <>
            {/* Overall Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Test Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Student Name</p>
                      <p className="text-lg font-semibold">{reportData.student.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Email</p>
                      <p className="text-lg font-semibold">{reportData.student.email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Score</p>
                      <p className="text-lg font-semibold">
                        {reportData.session.score} / {reportData.session.total_questions_answered}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Accuracy</p>
                      <p className="text-lg font-semibold">
                        {reportData.session.total_questions_answered > 0
                          ? ((reportData.session.score / reportData.session.total_questions_answered) * 100).toFixed(1)
                          : "0"}%
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Time</p>
                      <p className="text-lg font-semibold">{formatTime(reportData.session.total_time_taken_seconds)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Status</p>
                      <p className="text-lg font-semibold">{reportData.session.completed ? "Completed" : "Incomplete"}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Section-wise Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Section-wise Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reportData.sections.map((section) => {
                    const answeredQuestions = section.questions.filter((q) => q.selected_answer !== null).length;
                    const correctAnswers = section.questions.filter((q) => q.is_correct === true).length;
                    const sectionTime = section.questions.reduce((sum, q) => sum + (q.time_taken_seconds || 0), 0);
                    const sectionAccuracy = answeredQuestions > 0 ? ((correctAnswers / answeredQuestions) * 100).toFixed(1) : "0";

                    return (
                      <div key={section.id} className="border rounded-lg p-4">
                        <h3 className="font-semibold mb-3">{section.name}</h3>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Score</p>
                            <p className="font-semibold">{correctAnswers} / {answeredQuestions}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Accuracy</p>
                            <p className="font-semibold">{sectionAccuracy}%</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Time Taken</p>
                            <p className="font-semibold">{formatTime(sectionTime)}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Detailed Question-by-Question Results */}
            {reportData.sections.map((section) => (
              <Card key={section.id}>
                <CardHeader>
                  <CardTitle>{section.name} - Detailed Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {section.questions.map((question, qIndex) => {
                      const statusColor = question.is_correct === true
                        ? "text-green-600"
                        : question.is_correct === false
                        ? "text-red-600"
                        : "text-gray-400";

                      return (
                        <div key={question.id} className="border-b pb-4 last:border-b-0">
                          <div className="flex items-start gap-2 mb-2">
                            <span className={`font-bold ${statusColor}`}>Q{qIndex + 1}.</span>
                            <div className="flex-1">
                              <p className="font-medium">{question.question}</p>
                              <p className="text-xs text-muted-foreground mt-1">{question.description}</p>
                            </div>
                          </div>

                          <div className="ml-8 space-y-2 mt-3">
                            {question.options.map((option, optIndex) => {
                              const isCorrect = optIndex === question.correctAnswer;
                              const isSelected = optIndex === question.selected_answer;

                              let optionStyle = "text-gray-700";
                              if (isCorrect && isSelected) {
                                optionStyle = "text-green-600 font-medium";
                              } else if (isCorrect) {
                                optionStyle = "text-green-600 font-medium";
                              } else if (isSelected) {
                                optionStyle = "text-red-600 font-medium";
                              }

                              return (
                                <div key={optIndex} className={optionStyle}>
                                  <span className="font-mono text-sm">
                                    {String.fromCharCode(65 + optIndex)}. {option}
                                  </span>
                                </div>
                              );
                            })}
                          </div>

                          <div className="ml-8 mt-3 text-xs text-muted-foreground">
                            Time: {formatTime(question.time_taken_seconds)}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            ))}
          </>
        )}
      </div>
    </div>
  );
}

export default function ReportPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-muted/30 p-6 flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    }>
      <ReportContent />
    </Suspense>
  );
}
