"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { IconInnerShadowTop, IconArrowRight } from "@tabler/icons-react";
import { toast } from "sonner";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSeparator,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { otpApi } from "@/lib/api";
import Cookies from "js-cookie";

function OTPForm() {
  const [otp, setOtp] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();

  // Prefill OTP from URL if present
  useEffect(() => {
    const otpFromUrl = searchParams.get("otp");
    if (otpFromUrl) {
      // Only allow alphanumeric and limit to 6 characters
      const sanitized = otpFromUrl
        .replace(/[^a-zA-Z0-9]/g, "")
        .slice(0, 6)
        .toUpperCase();
      if (sanitized) {
        setOtp(sanitized);
        toast.info("OTP pre-filled from link");
      }
    }
  }, [searchParams]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (otp.length !== 6) {
      toast.error("Please enter a complete 6-digit OTP");
      return;
    }

    // Prevent duplicate submissions
    if (isVerifying) {
      return;
    }

    setIsLoading(true);
    setIsVerifying(true);

    try {
      const response = await otpApi.verifyOTP(otp);

      // Store session data in cookies (expires in 1 hour)
      Cookies.set("session_token", response.session_token || "", { expires: 1/24 });
      Cookies.set("user_email", response.email || "", { expires: 1/24 });
      Cookies.set("user_name", response.name || "", { expires: 1/24 });

      toast.success(response.message);
      router.push("/test");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to verify OTP");
      setIsVerifying(false);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="max-w-md w-full">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
          <div className="bg-primary/10 p-4 rounded-full">
            <IconInnerShadowTop className="h-12 w-12 text-primary" />
          </div>
        </div>
        <CardTitle className="text-2xl">Quiz Login</CardTitle>
        <CardDescription>
          Please enter the 6-digit code sent to your email
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-center block mb-4">One-Time Password</Label>
            <div className="flex justify-center">
              <InputOTP maxLength={6} value={otp} onChange={setOtp}>
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                </InputOTPGroup>
                <InputOTPSeparator />
                <InputOTPGroup>
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-2 pt-6">
          <Button
            type="submit"
            size="lg"
            className="w-full"
            disabled={isLoading || otp.length !== 6}
          >
            {isLoading ? "Verifying..." : "Verify OTP"}
            <IconArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}

export default function HomePage() {
  return (
    <div className="min-h-screen bg-muted/30 flex items-center justify-center p-4">
      <Suspense
        fallback={
          <Card className="max-w-md w-full">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="bg-primary/10 p-4 rounded-full">
                  <IconInnerShadowTop className="h-12 w-12 text-primary" />
                </div>
              </div>
              <CardTitle className="text-2xl">Loading...</CardTitle>
            </CardHeader>
          </Card>
        }
      >
        <OTPForm />
      </Suspense>
    </div>
  );
}
