'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { adminApi } from '@/lib/api';
import { AppSidebar } from "@/components/app-sidebar"
import { SiteHeader } from "@/components/site-header"
import {
  SidebarInset,
  SidebarProvider,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { toast } from "sonner"

const CONFIRMATION_TEXT = "Delete database tables";

export default function SettingsPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [isResetDialogOpen, setIsResetDialogOpen] = useState(false);
  const [confirmationText, setConfirmationText] = useState("");
  const [isResetting, setIsResetting] = useState(false);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/admin');
    }
  }, [isAuthenticated, isLoading, router]);

  const handleResetDatabase = async () => {
    if (confirmationText !== CONFIRMATION_TEXT) {
      toast.error("Confirmation text doesn't match");
      return;
    }

    setIsResetting(true);
    try {
      const response = await adminApi.resetDatabase();
      toast.success(response.message);
      setIsResetDialogOpen(false);
      setConfirmationText("");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to reset database"
      );
    } finally {
      setIsResetting(false);
    }
  };

  const handleDialogClose = (open: boolean) => {
    setIsResetDialogOpen(open);
    if (!open) {
      setConfirmationText("");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": "calc(var(--spacing) * 72)",
          "--header-height": "calc(var(--spacing) * 12)",
        } as React.CSSProperties
      }
    >
      <AppSidebar variant="inset" />
      <SidebarInset>
        <SiteHeader title="Settings" />
        <div className="flex flex-1 flex-col">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6 px-4 lg:px-6">
              <div>
                <h1 className="text-2xl font-bold mb-2">Settings</h1>
                <p className="text-muted-foreground">
                  Manage your application settings and preferences
                </p>
              </div>

              <div className="grid gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Database</CardTitle>
                    <CardDescription>
                      Manage your database settings
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Dialog open={isResetDialogOpen} onOpenChange={handleDialogClose}>
                      <DialogTrigger asChild>
                        <Button variant="destructive">
                          Reset Database
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Are you absolutely sure?</DialogTitle>
                          <DialogDescription>
                            This action cannot be undone. This will permanently delete all
                            data from the database including students, questions, and results.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="py-4">
                          <Label htmlFor="confirmation" className="text-sm font-medium">
                            Type <span className="font-bold text-destructive">{CONFIRMATION_TEXT}</span> to confirm
                          </Label>
                          <Input
                            id="confirmation"
                            type="text"
                            placeholder={CONFIRMATION_TEXT}
                            value={confirmationText}
                            onChange={(e) => setConfirmationText(e.target.value)}
                            className="mt-2"
                            autoComplete="off"
                          />
                        </div>
                        <DialogFooter>
                          <Button
                            variant="outline"
                            onClick={() => handleDialogClose(false)}
                            disabled={isResetting}
                          >
                            Cancel
                          </Button>
                          <Button
                            variant="destructive"
                            onClick={handleResetDatabase}
                            disabled={confirmationText !== CONFIRMATION_TEXT || isResetting}
                          >
                            {isResetting ? "Resetting..." : "Yes, Reset Database"}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>General Settings</CardTitle>
                    <CardDescription>
                      Configure general application settings
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Additional settings will be available here.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
