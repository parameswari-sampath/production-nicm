'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { mailApi, EmailLog } from '@/lib/api';
import { AppSidebar } from "@/components/app-sidebar"
import { SiteHeader } from "@/components/site-header"
import {
  SidebarInset,
  SidebarProvider,
} from "@/components/ui/sidebar"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function TrackerPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [sentLogs, setSentLogs] = useState<EmailLog[]>([]);
  const [isLoadingSent, setIsLoadingSent] = useState(false);

  // Dummy data for failed
  const [failedLogs] = useState([
    { id: 3, email: "invalid@example.com", subject: "Test", status: "failed", sentAt: "2024-01-13 09:15", reason: "Invalid email" },
  ]);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/admin');
    }
  }, [isAuthenticated, isLoading, router]);

  useEffect(() => {
    const fetchSentLogs = async () => {
      setIsLoadingSent(true);
      try {
        const data = await mailApi.getEmailLogs('sent');
        setSentLogs(data.logs || []);
      } catch (error) {
        console.error('Failed to fetch sent logs:', error);
      } finally {
        setIsLoadingSent(false);
      }
    };

    if (isAuthenticated) {
      fetchSentLogs();
    }
  }, [isAuthenticated]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": "calc(var(--spacing) * 72)",
          "--header-height": "calc(var(--spacing) * 12)",
        } as React.CSSProperties
      }
    >
      <AppSidebar variant="inset" />
      <SidebarInset>
        <SiteHeader title="Tracker" />
        <div className="flex flex-1 flex-col">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6 px-4 lg:px-6">
              <Tabs defaultValue="sent" className="w-full">
                <TabsList>
                  <TabsTrigger value="sent">
                    Sent <Badge variant="secondary" className="ml-2">{sentLogs.length}</Badge>
                  </TabsTrigger>
                  <TabsTrigger value="failed">
                    Failed <Badge variant="secondary" className="ml-2">{failedLogs.length}</Badge>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="sent" className="mt-4">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>S.No</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Response Code</TableHead>
                          <TableHead>Response Message</TableHead>
                          <TableHead>Sent At</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoadingSent ? (
                          <TableRow>
                            <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                              Loading...
                            </TableCell>
                          </TableRow>
                        ) : sentLogs.length > 0 ? (
                          sentLogs.map((log, index) => (
                            <TableRow key={log.id}>
                              <TableCell>{index + 1}</TableCell>
                              <TableCell>{log.email}</TableCell>
                              <TableCell>{log.subject}</TableCell>
                              <TableCell><Badge variant="secondary">{log.response_code}</Badge></TableCell>
                              <TableCell>{log.response_message}</TableCell>
                              <TableCell>{new Date(log.sent_at).toLocaleString()}</TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                              No emails sent yet
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                <TabsContent value="failed" className="mt-4">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Response Code</TableHead>
                          <TableHead>Response Message</TableHead>
                          <TableHead>Sent At</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {failedLogs.length > 0 ? (
                          failedLogs.map((log) => (
                            <TableRow key={log.id}>
                              <TableCell>{log.id}</TableCell>
                              <TableCell>{log.email}</TableCell>
                              <TableCell>{log.subject}</TableCell>
                              <TableCell><Badge variant="destructive">{log.status}</Badge></TableCell>
                              <TableCell className="text-destructive">{log.reason}</TableCell>
                              <TableCell>{log.sentAt}</TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                              No failed emails
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
