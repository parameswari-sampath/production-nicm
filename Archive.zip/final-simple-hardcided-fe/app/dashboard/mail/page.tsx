'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { mailApi, EmailLog } from '@/lib/api';
import { toast } from 'sonner';
import { AppSidebar } from "@/components/app-sidebar"
import { SiteHeader } from "@/components/site-header"
import {
  SidebarInset,
  SidebarProvider,
} from "@/components/ui/sidebar"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { Check, ChevronsUpDown } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { IconPlus } from "@tabler/icons-react"

export default function MailPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [totalEmails, setTotalEmails] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEmail, setSelectedEmail] = useState("");
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [open, setOpen] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [sendAllData, setSendAllData] = useState({ subject: '', message: '' });
  const [sentLogs, setSentLogs] = useState<EmailLog[]>([]);
  const [failedLogs, setFailedLogs] = useState<EmailLog[]>([]);
  const [isLoadingSent, setIsLoadingSent] = useState(false);
  const [isLoadingFailed, setIsLoadingFailed] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/admin');
    }
  }, [isAuthenticated, isLoading, router]);

  useEffect(() => {
    const fetchEmailStats = async () => {
      try {
        const data = await mailApi.getEmailStats();
        setTotalEmails(data.total_emails);
      } catch (error) {
        console.error('Failed to fetch email stats:', error);
      }
    };

    const fetchSentLogs = async () => {
      setIsLoadingSent(true);
      try {
        const data = await mailApi.getEmailLogs('sent');
        setSentLogs(data.logs || []);
      } catch (error) {
        toast.error(
          error instanceof Error ? error.message : "Failed to fetch sent logs"
        );
      } finally {
        setIsLoadingSent(false);
      }
    };

    const fetchFailedLogs = async () => {
      setIsLoadingFailed(true);
      try {
        const data = await mailApi.getEmailLogs('failed');
        setFailedLogs(data.logs || []);
      } catch (error) {
        toast.error(
          error instanceof Error ? error.message : "Failed to fetch failed logs"
        );
      } finally {
        setIsLoadingFailed(false);
      }
    };

    if (isAuthenticated) {
      fetchEmailStats();
      fetchSentLogs();
      fetchFailedLogs();
    }
  }, [isAuthenticated, refreshKey]);

  // Search email as user types
  useEffect(() => {
    const searchEmail = async () => {
      if (!searchQuery || searchQuery.length < 3) {
        setSearchResults([]);
        return;
      }

      setIsSearching(true);
      try {
        const data = await mailApi.searchEmail(searchQuery);
        if (data.emails && data.emails.length > 0) {
          setSearchResults(data.emails);
        } else {
          setSearchResults([]);
        }
      } catch (error) {
        console.error('Failed to search email:', error);
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    };

    const debounceTimer = setTimeout(searchEmail, 300);
    return () => clearTimeout(debounceTimer);
  }, [searchQuery]);

  const handleSendToAll = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!sendAllData.subject || !sendAllData.message) {
      toast.error("Please fill in subject and message");
      return;
    }

    setIsSending(true);
    try {
      const payload = {
        subject: sendAllData.subject,
        html_body: sendAllData.message,
      };
      console.log("Sending payload:", payload);

      const response = await mailApi.sendToAll(payload);
      console.log("Response:", response);

      if (response.sent === 0) {
        toast.error(`Failed to send emails. ${response.total} total, ${response.sent} sent.`);
      } else {
        toast.success(`${response.sent} emails sent successfully out of ${response.total}!`);
      }
      setSendAllData({ subject: '', message: '' });
      setRefreshKey(prev => prev + 1); // Refresh sent logs
    } catch (error) {
      console.error("Send error:", error);
      toast.error(
        error instanceof Error ? error.message : "Failed to send emails"
      );
    } finally {
      setIsSending(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": "calc(var(--spacing) * 72)",
          "--header-height": "calc(var(--spacing) * 12)",
        } as React.CSSProperties
      }
    >
      <AppSidebar variant="inset" />
      <SidebarInset>
        <SiteHeader title="Mail" />
        <div className="flex flex-1 flex-col">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
              <Tabs defaultValue="sent" className="w-full px-4 lg:px-6">
                <div className="flex items-center justify-between mb-4">
                  <TabsList>
                    <TabsTrigger value="sent">
                      Sent <Badge variant="secondary" className="ml-2">{sentLogs.length}</Badge>
                    </TabsTrigger>
                    <TabsTrigger value="failed">
                      Failed <Badge variant="secondary" className="ml-2">{failedLogs.length}</Badge>
                    </TabsTrigger>
                  </TabsList>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <IconPlus />
                        <span className="hidden lg:inline">Send Mail</span>
                        <span className="lg:hidden">Send</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Send Mail</DialogTitle>
                        <DialogDescription>
                          Send email to students
                        </DialogDescription>
                      </DialogHeader>
                      <Tabs defaultValue="individual" className="w-full">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="individual">Individual</TabsTrigger>
                          <TabsTrigger value="sendAll">Send to All</TabsTrigger>
                          <TabsTrigger value="resendFailed">Resend Failed</TabsTrigger>
                        </TabsList>
                        <TabsContent value="individual" className="space-y-4 pt-4">
                          <div className="grid gap-3">
                            <Label htmlFor="recipient">Recipient Email</Label>
                            <Popover open={open} onOpenChange={setOpen}>
                              <PopoverTrigger asChild>
                                <Button
                                  variant="outline"
                                  role="combobox"
                                  aria-expanded={open}
                                  className="w-full justify-between"
                                >
                                  {selectedEmail || "Search email..."}
                                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="p-0" align="start" style={{ width: 'var(--radix-popover-trigger-width)' }}>
                                <Command>
                                  <CommandInput
                                    placeholder="Type email to search..."
                                    value={searchQuery}
                                    onValueChange={setSearchQuery}
                                  />
                                  <CommandList>
                                    <CommandEmpty>
                                      {isSearching ? "Searching..." : searchQuery.length < 3 ? "Type at least 3 characters" : "No email found"}
                                    </CommandEmpty>
                                    {searchResults.length > 0 && (
                                      <CommandGroup>
                                        {searchResults.map((email) => (
                                          <CommandItem
                                            key={email}
                                            value={email}
                                            onSelect={(currentValue: string) => {
                                              setSelectedEmail(currentValue === selectedEmail ? "" : currentValue);
                                              setOpen(false);
                                            }}
                                          >
                                            <Check
                                              className={cn(
                                                "mr-2 h-4 w-4",
                                                selectedEmail === email ? "opacity-100" : "opacity-0"
                                              )}
                                            />
                                            {email}
                                          </CommandItem>
                                        ))}
                                      </CommandGroup>
                                    )}
                                  </CommandList>
                                </Command>
                              </PopoverContent>
                            </Popover>
                          </div>
                          <div className="grid gap-3">
                            <Label htmlFor="subject">Subject</Label>
                            <Input
                              id="subject"
                              type="text"
                              placeholder="Enter email subject"
                              required
                            />
                          </div>
                          <div className="grid gap-3">
                            <Label htmlFor="message">Message</Label>
                            <Textarea
                              id="message"
                              placeholder="Enter your message"
                              rows={5}
                              required
                            />
                          </div>
                        </TabsContent>
                        <TabsContent value="sendAll" className="space-y-4 pt-4">
                          <form onSubmit={handleSendToAll}>
                            <div className="space-y-4">
                              <div className="rounded-md bg-muted p-3 text-sm">
                                <p className="font-medium">Send to all students in the database</p>
                                <p className="text-muted-foreground mt-1">
                                  Total students: {totalEmails}
                                </p>
                                <p className="text-xs text-muted-foreground mt-2">
                                  Use {`{{name}}`} in your message to personalize with student names
                                </p>
                              </div>
                              <div className="grid gap-3">
                                <Label htmlFor="all-subject">Subject</Label>
                                <Input
                                  id="all-subject"
                                  type="text"
                                  placeholder="Enter email subject"
                                  value={sendAllData.subject}
                                  onChange={(e) => setSendAllData({ ...sendAllData, subject: e.target.value })}
                                  required
                                />
                              </div>
                              <div className="grid gap-3">
                                <Label htmlFor="all-message">Message (HTML)</Label>
                                <Textarea
                                  id="all-message"
                                  placeholder="Enter your HTML message. Use {{name}} for personalization."
                                  rows={5}
                                  value={sendAllData.message}
                                  onChange={(e) => setSendAllData({ ...sendAllData, message: e.target.value })}
                                  required
                                />
                              </div>
                              <Button type="submit" className="w-full" disabled={isSending}>
                                {isSending ? "Sending..." : "Send to All Students"}
                              </Button>
                            </div>
                          </form>
                        </TabsContent>
                        <TabsContent value="resendFailed" className="space-y-4 pt-4">
                          <div className="rounded-md bg-muted p-3 text-sm">
                            <p className="font-medium">Resend to all failed recipients</p>
                            <p className="text-muted-foreground mt-1">
                              Failed emails: 0
                            </p>
                          </div>
                          <div className="grid gap-3">
                            <Label htmlFor="retry-subject">Subject</Label>
                            <Input
                              id="retry-subject"
                              type="text"
                              placeholder="Enter email subject"
                              required
                            />
                          </div>
                          <div className="grid gap-3">
                            <Label htmlFor="retry-message">Message</Label>
                            <Textarea
                              id="retry-message"
                              placeholder="Enter your message"
                              rows={5}
                              required
                            />
                          </div>
                        </TabsContent>
                      </Tabs>
                    </DialogContent>
                  </Dialog>
                </div>

                <TabsContent value="sent">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>S.No</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Response Code</TableHead>
                          <TableHead>Response Message</TableHead>
                          <TableHead>Sent At</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoadingSent ? (
                          <TableRow>
                            <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                              Loading...
                            </TableCell>
                          </TableRow>
                        ) : sentLogs.length > 0 ? (
                          sentLogs.map((log, index) => (
                            <TableRow key={log.id}>
                              <TableCell>{index + 1}</TableCell>
                              <TableCell>{log.email}</TableCell>
                              <TableCell>{log.subject}</TableCell>
                              <TableCell><Badge variant="secondary">{log.response_code}</Badge></TableCell>
                              <TableCell>{log.response_message}</TableCell>
                              <TableCell>{new Date(log.sent_at).toLocaleString()}</TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                              No sent emails yet
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                <TabsContent value="failed">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>S.No</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Response Code</TableHead>
                          <TableHead>Response Message</TableHead>
                          <TableHead>Sent At</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoadingFailed ? (
                          <TableRow>
                            <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                              Loading...
                            </TableCell>
                          </TableRow>
                        ) : failedLogs.length > 0 ? (
                          failedLogs.map((log, index) => (
                            <TableRow key={log.id}>
                              <TableCell>{index + 1}</TableCell>
                              <TableCell>{log.email}</TableCell>
                              <TableCell>{log.subject}</TableCell>
                              <TableCell><Badge variant="destructive">{log.response_code}</Badge></TableCell>
                              <TableCell className="text-destructive">{log.response_message}</TableCell>
                              <TableCell>{new Date(log.sent_at).toLocaleString()}</TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                              No failed emails
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
