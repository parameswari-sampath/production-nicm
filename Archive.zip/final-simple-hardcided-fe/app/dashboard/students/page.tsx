"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";
import { studentsApi, type Student } from "@/lib/api";
import { toast } from "sonner";
import Papa from "papaparse";
import * as XLSX from "xlsx";
import { AppSidebar } from "@/components/app-sidebar";
import { SiteHeader } from "@/components/site-header";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { IconPlus, IconChevronLeft, IconChevronRight, IconChevronsLeft, IconChevronsRight } from "@tabler/icons-react";

export default function StudentsPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [students, setStudents] = useState<Student[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingStudents, setIsLoadingStudents] = useState(true);
  const [formData, setFormData] = useState({ name: "", email: "" });
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [deletingStudent, setDeletingStudent] = useState<Student | null>(null);
  const [bulkFile, setBulkFile] = useState<File | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalStudents, setTotalStudents] = useState(0);
  const [studentsPerPage, setStudentsPerPage] = useState(10);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push("/admin");
    }
  }, [isAuthenticated, isLoading, router]);

  useEffect(() => {
    const fetchStudents = async () => {
      setIsLoadingStudents(true);
      try {
        const offset = (currentPage - 1) * studentsPerPage;
        const data = await studentsApi.getAllStudents(studentsPerPage, offset);
        console.log("API Response:", data);
        setStudents(Array.isArray(data.students) ? data.students : []);
        setTotalStudents(data.total || 0); // Use total from response, default to 0
      } catch (error) {
        toast.error(
          error instanceof Error ? error.message : "Failed to fetch students"
        );
        setStudents([]);
      } finally {
        setIsLoadingStudents(false);
      }
    };

    if (isAuthenticated) {
      fetchStudents();
    }
  }, [isAuthenticated, currentPage, studentsPerPage, refreshKey]);

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.email) {
      toast.error("Please fill in all fields");
      return;
    }

    setIsSubmitting(true);
    try {
      await studentsApi.addStudent(formData);
      setFormData({ name: "", email: "" });
      setIsDialogOpen(false);
      toast.success("Student added successfully!");
      setCurrentPage(1); // Reset to first page to see the new student
      setRefreshKey(prev => prev + 1); // Trigger refetch
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to add student"
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditClick = (student: Student) => {
    setEditingStudent(student);
    setIsEditDialogOpen(true);
  };

  const handleUpdateStudent = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!editingStudent) return;

    setIsSubmitting(true);
    try {
      await studentsApi.updateStudent(
        editingStudent.id,
        {
          name: editingStudent.name,
          email: editingStudent.email,
        }
      );
      setIsEditDialogOpen(false);
      setEditingStudent(null);
      toast.success("Student updated successfully!");
      setRefreshKey(prev => prev + 1); // Trigger refetch
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to update student"
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteClick = (student: Student) => {
    setDeletingStudent(student);
    setIsDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!deletingStudent) return;

    setIsSubmitting(true);
    try {
      await studentsApi.deleteStudent(deletingStudent.id);
      setIsDeleteDialogOpen(false);
      setDeletingStudent(null);
      toast.success("Student deleted successfully!");
      setRefreshKey(prev => prev + 1); // Trigger refetch
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete student"
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const parseFileData = (
    file: File
  ): Promise<Array<{ name: string; email: string }>> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      const fileExtension = file.name.split(".").pop()?.toLowerCase();

      reader.onload = (e) => {
        try {
          const data = e.target?.result;

          if (fileExtension === "csv") {
            // Parse CSV - handle files that may have a title row before headers
            let csvData = data as string;

            // Check if first line is a title (like "Table 1") and skip it
            const lines = csvData.split(/\r?\n/);
            if (lines[0] && !lines[0].includes(',') && lines.length > 2) {
              // First line has no comma, likely a title - skip it
              csvData = lines.slice(1).join('\n');
            }

            Papa.parse(csvData, {
              header: true,
              skipEmptyLines: true,
              transformHeader: (header: string) => header.trim(), // Trim header names
              complete: (results) => {
                const students = (results.data as Record<string, string>[])
                  .map((row) => {
                    // Try different column name variations (headers are already trimmed)
                    const name = row["Full Name"] || row["full name"] || row["Full name"] || row["name"] || row["Name"] || "";
                    const email = row["Email"] || row["email"] || row["EMAIL"] || "";
                    return { name: name.trim(), email: email.trim() };
                  })
                  .filter((s) => s.name && s.email && s.email.includes("@"));
                resolve(students);
              },
              error: (error: Error) => reject(error),
            });
          } else if (fileExtension === "xlsx" || fileExtension === "xls") {
            // Parse Excel
            const workbook = XLSX.read(data, { type: "binary" });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet) as Record<
              string,
              string
            >[];

            const students = jsonData
              .map((row) => ({
                name: row["Full Name"] || row["name"] || "",
                email: row["Email"] || row["email"] || "",
              }))
              .filter((s) => s.name && s.email);
            resolve(students);
          } else {
            reject(new Error("Unsupported file format"));
          }
        } catch (error) {
          reject(error);
        }
      };

      reader.onerror = () => reject(new Error("Failed to read file"));

      if (fileExtension === "csv") {
        reader.readAsText(file);
      } else {
        reader.readAsBinaryString(file);
      }
    });
  };

  const handleBulkUpload = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!bulkFile) {
      toast.error("Please select a file");
      return;
    }

    setIsSubmitting(true);
    try {
      const studentsData = await parseFileData(bulkFile);

      if (studentsData.length === 0) {
        toast.error("No valid student data found in file");
        return;
      }

      console.log("Sending to backend:", {
        students: studentsData.slice(0, 5), // Show first 5 for debugging
        total: studentsData.length,
      });

      const response = await studentsApi.bulkCreateStudents({
        students: studentsData,
      });

      console.log("Backend response:", response);

      setBulkFile(null);
      setIsDialogOpen(false);

      // Handle response - could be simple count or detailed with duplicates
      if (response.success !== undefined) {
        // Has duplicates
        if (response.failed && response.failed > 0) {
          toast.warning(
            `${response.success} students added successfully. ${response.failed} failed (${response.duplicates?.length || 0} duplicates).`,
            { duration: 5000 }
          );
        } else {
          toast.success(`${response.success} students added successfully!`);
        }
      } else if (response.count !== undefined) {
        // Simple success
        toast.success(`${response.count} students added successfully!`);
      } else {
        toast.success(response.message);
      }

      setCurrentPage(1); // Reset to first page to see the new students
      setRefreshKey(prev => prev + 1); // Trigger refetch
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to upload students"
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": "calc(var(--spacing) * 72)",
          "--header-height": "calc(var(--spacing) * 12)",
        } as React.CSSProperties
      }
    >
      <AppSidebar variant="inset" />
      <SidebarInset>
        <SiteHeader title="Students" />
        <div className="flex flex-1 flex-col">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
              <Tabs defaultValue="all-students" className="w-full px-4 lg:px-6">
                <div className="flex items-center justify-between mb-4">
                  <TabsList>
                    <TabsTrigger value="all-students">All Students</TabsTrigger>
                    <TabsTrigger value="attended-conference">
                      Attended Conference
                    </TabsTrigger>
                    <TabsTrigger value="attended-test">
                      Attended Test
                    </TabsTrigger>
                  </TabsList>
                  <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <IconPlus />
                        <span className="hidden lg:inline">Add Student</span>
                        <span className="lg:hidden">Add</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Add Student</DialogTitle>
                        <DialogDescription>
                          Add a new student or upload students in bulk
                        </DialogDescription>
                      </DialogHeader>
                      <Tabs defaultValue="single" className="w-full">
                        <TabsList className="grid w-full grid-cols-2">
                          <TabsTrigger value="single">
                            Single Student
                          </TabsTrigger>
                          <TabsTrigger value="bulk">Bulk Upload</TabsTrigger>
                        </TabsList>
                        <TabsContent value="single" className="space-y-4 pt-4">
                          <form
                            onSubmit={handleAddStudent}
                            className="space-y-4"
                          >
                            <div className="grid gap-3">
                              <Label htmlFor="fullname">Full Name</Label>
                              <Input
                                id="fullname"
                                type="text"
                                placeholder="John Doe"
                                value={formData.name}
                                onChange={(e) =>
                                  setFormData((prev) => ({
                                    ...prev,
                                    name: e.target.value,
                                  }))
                                }
                                required
                              />
                            </div>
                            <div className="grid gap-3">
                              <Label htmlFor="email">Email</Label>
                              <Input
                                id="email"
                                type="email"
                                placeholder="john.doe@example.com"
                                value={formData.email}
                                onChange={(e) =>
                                  setFormData((prev) => ({
                                    ...prev,
                                    email: e.target.value,
                                  }))
                                }
                                required
                              />
                            </div>
                            <DialogFooter>
                              <Button
                                type="submit"
                                className="w-full"
                                disabled={isSubmitting}
                              >
                                {isSubmitting ? "Adding..." : "Add Student"}
                              </Button>
                            </DialogFooter>
                          </form>
                        </TabsContent>
                        <TabsContent value="bulk" className="space-y-4 pt-4">
                          <form
                            onSubmit={handleBulkUpload}
                            className="space-y-4"
                          >
                            <div className="grid gap-3">
                              <Label htmlFor="file">
                                Upload CSV or Excel File
                              </Label>
                              <Input
                                id="file"
                                type="file"
                                accept=".csv,.xlsx,.xls"
                                onChange={(e) =>
                                  setBulkFile(e.target.files?.[0] || null)
                                }
                                required
                              />
                              <p className="text-sm text-muted-foreground">
                                File should contain columns:{" "}
                                <strong>Full Name</strong> and{" "}
                                <strong>Email</strong>
                                <br />
                                Supported formats: CSV, Excel (.xlsx, .xls)
                                <br />
                                Max: 2000 students per upload
                              </p>
                            </div>
                            <DialogFooter>
                              <Button
                                type="submit"
                                className="w-full"
                                disabled={isSubmitting}
                              >
                                {isSubmitting
                                  ? "Uploading..."
                                  : "Upload Students"}
                              </Button>
                            </DialogFooter>
                          </form>
                        </TabsContent>
                      </Tabs>
                    </DialogContent>
                  </Dialog>
                </div>
                <TabsContent value="all-students">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-16">#</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoadingStudents ? (
                          <TableRow>
                            <TableCell colSpan={4} className="h-24 text-center">
                              Loading students...
                            </TableCell>
                          </TableRow>
                        ) : students.length === 0 ? (
                          <TableRow>
                            <TableCell
                              colSpan={4}
                              className="h-24 text-center text-muted-foreground"
                            >
                              No students found
                            </TableCell>
                          </TableRow>
                        ) : (
                          Array.isArray(students) && students.map((student, index) => (
                            <TableRow key={student.id}>
                              <TableCell>{(currentPage - 1) * studentsPerPage + index + 1}</TableCell>
                              <TableCell>{student.name}</TableCell>
                              <TableCell>{student.email}</TableCell>
                              <TableCell className="text-right">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleEditClick(student)}
                                >
                                  Edit
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDeleteClick(student)}
                                >
                                  Delete
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Pagination */}
                  <div className="flex items-center justify-between px-4 py-4 border-t">
                    <div className="text-sm text-muted-foreground">
                      Showing{" "}
                      <span className="font-medium">
                        {totalStudents === 0 ? 0 : ((currentPage - 1) * studentsPerPage) + 1}
                      </span>{" "}
                      to{" "}
                      <span className="font-medium">
                        {Math.min(currentPage * studentsPerPage, totalStudents)}
                      </span>{" "}
                      of{" "}
                      <span className="font-medium">{totalStudents}</span> students
                    </div>
                    <div className="flex items-center space-x-6 lg:space-x-8">
                      <div className="flex items-center space-x-2">
                        <p className="text-sm font-medium">Rows per page</p>
                        <Select
                          value={studentsPerPage.toString()}
                          onValueChange={(value) => {
                            setStudentsPerPage(Number(value));
                            setCurrentPage(1);
                          }}
                        >
                          <SelectTrigger className="h-8 w-[70px]">
                            <SelectValue placeholder={studentsPerPage} />
                          </SelectTrigger>
                          <SelectContent side="top">
                            {[10, 20, 30, 50, 100].map((pageSize) => (
                              <SelectItem key={pageSize} value={pageSize.toString()}>
                                {pageSize}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex w-[100px] items-center justify-center text-sm font-medium">
                        Page {currentPage} of {Math.ceil(totalStudents / studentsPerPage) || 1}
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          className="hidden h-8 w-8 p-0 lg:flex"
                          onClick={() => setCurrentPage(1)}
                          disabled={currentPage === 1}
                        >
                          <span className="sr-only">Go to first page</span>
                          <IconChevronsLeft className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          className="h-8 w-8 p-0"
                          onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                          disabled={currentPage === 1}
                        >
                          <span className="sr-only">Go to previous page</span>
                          <IconChevronLeft className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          className="h-8 w-8 p-0"
                          onClick={() => setCurrentPage(prev => Math.min(Math.ceil(totalStudents / studentsPerPage), prev + 1))}
                          disabled={currentPage === Math.ceil(totalStudents / studentsPerPage)}
                        >
                          <span className="sr-only">Go to next page</span>
                          <IconChevronRight className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          className="hidden h-8 w-8 p-0 lg:flex"
                          onClick={() => setCurrentPage(Math.ceil(totalStudents / studentsPerPage))}
                          disabled={currentPage === Math.ceil(totalStudents / studentsPerPage)}
                        >
                          <span className="sr-only">Go to last page</span>
                          <IconChevronsRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="attended-conference">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell
                            colSpan={4}
                            className="h-24 text-center text-muted-foreground"
                          >
                            No students attended conference yet
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>
                <TabsContent value="attended-test">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell
                            colSpan={4}
                            className="h-24 text-center text-muted-foreground"
                          >
                            No students attended test yet
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </SidebarInset>

      {/* Edit Student Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Student</DialogTitle>
            <DialogDescription>Update student information</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpdateStudent} className="space-y-4">
            <div className="grid gap-3">
              <Label htmlFor="edit-fullname">Full Name</Label>
              <Input
                id="edit-fullname"
                type="text"
                placeholder="John Doe"
                value={editingStudent?.name || ""}
                onChange={(e) =>
                  setEditingStudent((prev) =>
                    prev ? { ...prev, name: e.target.value } : null
                  )
                }
                required
              />
            </div>
            <div className="grid gap-3">
              <Label htmlFor="edit-email">Email</Label>
              <Input
                id="edit-email"
                type="email"
                placeholder="john.doe@example.com"
                value={editingStudent?.email || ""}
                onChange={(e) =>
                  setEditingStudent((prev) =>
                    prev ? { ...prev, email: e.target.value } : null
                  )
                }
                required
              />
            </div>
            <DialogFooter>
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Updating..." : "Update Student"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Student</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {deletingStudent?.name}? This
              action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={handleConfirmDelete}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SidebarProvider>
  );
}
