'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { AppSidebar } from "@/components/app-sidebar"
import { SiteHeader } from "@/components/site-header"
import {
  SidebarInset,
  SidebarProvider,
} from "@/components/ui/sidebar"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { IconPlus } from "@tabler/icons-react"

export default function QuestionsPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [questions] = useState([
    {
      id: 1,
      section: "React Basics",
      question: "What is React?",
      description: "Explain the fundamentals of React library",
      option_0: "A JavaScript library",
      option_1: "A CSS framework",
      option_2: "A database",
      option_3: "A server",
      correct_answer: 0 // Index of correct option
    },
    {
      id: 2,
      section: "React Hooks",
      question: "Explain useState hook",
      description: "Describe the purpose and usage of useState",
      option_0: "Manages state",
      option_1: "Handles routing",
      option_2: "Makes API calls",
      option_3: "Styles components",
      correct_answer: 0 // Index of correct option
    },
  ]);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/admin');
    }
  }, [isAuthenticated, isLoading, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": "calc(var(--spacing) * 72)",
          "--header-height": "calc(var(--spacing) * 12)",
        } as React.CSSProperties
      }
    >
      <AppSidebar variant="inset" />
      <SidebarInset>
        <SiteHeader title="Questions" />
        <div className="flex flex-1 flex-col">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
              <Tabs defaultValue="all-questions" className="w-full px-4 lg:px-6">
                <div className="flex items-center justify-between mb-4">
                  <TabsList>
                    <TabsTrigger value="all-questions">All Questions</TabsTrigger>
                  </TabsList>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <IconPlus />
                        <span className="hidden lg:inline">Add Question</span>
                        <span className="lg:hidden">Add</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Add Question</DialogTitle>
                        <DialogDescription>
                          Add a new question or upload questions in bulk
                        </DialogDescription>
                      </DialogHeader>
                      <Tabs defaultValue="single" className="w-full">
                        <TabsList className="grid w-full grid-cols-2">
                          <TabsTrigger value="single">Single Question</TabsTrigger>
                          <TabsTrigger value="bulk">Bulk Upload</TabsTrigger>
                        </TabsList>
                        <TabsContent value="single" className="space-y-4 pt-4">
                          <div className="grid gap-3">
                            <Label htmlFor="section">Section</Label>
                            <Input
                              id="section"
                              type="text"
                              placeholder="e.g., React Basics, JavaScript"
                              required
                            />
                          </div>
                          <div className="grid gap-3">
                            <Label htmlFor="question">Question</Label>
                            <Input
                              id="question"
                              type="text"
                              placeholder="Enter your question"
                              required
                            />
                          </div>
                          <div className="grid gap-3">
                            <Label htmlFor="description">Description</Label>
                            <Input
                              id="description"
                              type="text"
                              placeholder="Question description"
                              required
                            />
                          </div>
                          <div className="space-y-3">
                            <Label>Options (Select correct answer)</Label>
                            <div className="flex items-center gap-3">
                              <Checkbox
                                id="option_0_check"
                                checked={selectedOption === 0}
                                onCheckedChange={() => setSelectedOption(0)}
                              />
                              <Input
                                id="option_0"
                                type="text"
                                placeholder="Option 0"
                                className="flex-1"
                                required
                              />
                            </div>
                            <div className="flex items-center gap-3">
                              <Checkbox
                                id="option_1_check"
                                checked={selectedOption === 1}
                                onCheckedChange={() => setSelectedOption(1)}
                              />
                              <Input
                                id="option_1"
                                type="text"
                                placeholder="Option 1"
                                className="flex-1"
                                required
                              />
                            </div>
                            <div className="flex items-center gap-3">
                              <Checkbox
                                id="option_2_check"
                                checked={selectedOption === 2}
                                onCheckedChange={() => setSelectedOption(2)}
                              />
                              <Input
                                id="option_2"
                                type="text"
                                placeholder="Option 2"
                                className="flex-1"
                                required
                              />
                            </div>
                            <div className="flex items-center gap-3">
                              <Checkbox
                                id="option_3_check"
                                checked={selectedOption === 3}
                                onCheckedChange={() => setSelectedOption(3)}
                              />
                              <Input
                                id="option_3"
                                type="text"
                                placeholder="Option 3"
                                className="flex-1"
                                required
                              />
                            </div>
                          </div>
                        </TabsContent>
                        <TabsContent value="bulk" className="space-y-4 pt-4">
                          <div className="grid gap-3">
                            <Label htmlFor="file">Upload CSV File</Label>
                            <Input
                              id="file"
                              type="file"
                              accept=".csv"
                              required
                            />
                            <p className="text-sm text-muted-foreground">
                              CSV should contain columns: SECTION, QUESTION, DESCRIPTION, OPTION_0, OPTION_1, OPTION_2, OPTION_3, CORRECT_ANSWER (0-3 index)
                            </p>
                          </div>
                        </TabsContent>
                      </Tabs>
                      <DialogFooter>
                        <Button type="submit" className="w-full">
                          Add Question
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
                <TabsContent value="all-questions">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Section</TableHead>
                          <TableHead>Question</TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>Correct Answer</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {questions.map((question) => {
                          const correctOptionKey = `option_${question.correct_answer}` as keyof typeof question;
                          return (
                            <TableRow key={question.id}>
                              <TableCell>{question.id}</TableCell>
                              <TableCell>{question.section}</TableCell>
                              <TableCell>{question.question}</TableCell>
                              <TableCell className="max-w-xs truncate">{question.description}</TableCell>
                              <TableCell>
                                Option {question.correct_answer}: {String(question[correctOptionKey])}
                              </TableCell>
                              <TableCell className="text-right">
                                <Button variant="ghost" size="sm">Edit</Button>
                                <Button variant="ghost" size="sm">Delete</Button>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
