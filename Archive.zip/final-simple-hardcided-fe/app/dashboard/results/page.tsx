'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { AppSidebar } from "@/components/app-sidebar"
import { SiteHeader } from "@/components/site-header"
import {
  SidebarInset,
  SidebarProvider,
} from "@/components/ui/sidebar"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function ResultsPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const router = useRouter();

  const [section1Results] = useState([
    { id: 1, studentName: "John Doe", email: "john.doe@example.com", score: 85, totalQuestions: 10, percentage: 85 },
    { id: 2, studentName: "Jane Smith", email: "jane.smith@example.com", score: 92, totalQuestions: 10, percentage: 92 },
  ]);

  const [section2Results] = useState([
    { id: 3, studentName: "Bob Johnson", email: "bob.johnson@example.com", score: 78, totalQuestions: 10, percentage: 78 },
  ]);

  const [section3Results] = useState([
    { id: 4, studentName: "Alice Williams", email: "alice.w@example.com", score: 95, totalQuestions: 10, percentage: 95 },
  ]);

  const [section4Results] = useState([
    { id: 5, studentName: "Charlie Brown", email: "charlie.b@example.com", score: 88, totalQuestions: 10, percentage: 88 },
  ]);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/admin');
    }
  }, [isAuthenticated, isLoading, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const getPercentageBadge = (percentage: number) => {
    if (percentage >= 90) return <Badge className="bg-green-500">Excellent</Badge>;
    if (percentage >= 75) return <Badge className="bg-blue-500">Good</Badge>;
    if (percentage >= 60) return <Badge className="bg-yellow-500">Average</Badge>;
    return <Badge variant="destructive">Poor</Badge>;
  };

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": "calc(var(--spacing) * 72)",
          "--header-height": "calc(var(--spacing) * 12)",
        } as React.CSSProperties
      }
    >
      <AppSidebar variant="inset" />
      <SidebarInset>
        <SiteHeader title="Results" />
        <div className="flex flex-1 flex-col">
          <div className="@container/main flex flex-1 flex-col gap-2">
            <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
              <Tabs defaultValue="section1" className="w-full px-4 lg:px-6">
                <div className="flex items-center justify-between mb-4">
                  <TabsList>
                    <TabsTrigger value="section1">Section 1</TabsTrigger>
                    <TabsTrigger value="section2">Section 2</TabsTrigger>
                    <TabsTrigger value="section3">Section 3</TabsTrigger>
                    <TabsTrigger value="section4">Section 4</TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="section1">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Student Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Score</TableHead>
                          <TableHead>Total Questions</TableHead>
                          <TableHead>Percentage</TableHead>
                          <TableHead>Grade</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {section1Results.length > 0 ? (
                          section1Results.map((result) => (
                            <TableRow key={result.id}>
                              <TableCell>{result.id}</TableCell>
                              <TableCell>{result.studentName}</TableCell>
                              <TableCell>{result.email}</TableCell>
                              <TableCell>{result.score}</TableCell>
                              <TableCell>{result.totalQuestions}</TableCell>
                              <TableCell>{result.percentage}%</TableCell>
                              <TableCell>{getPercentageBadge(result.percentage)}</TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                              No results for Section 1 yet
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                <TabsContent value="section2">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Student Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Score</TableHead>
                          <TableHead>Total Questions</TableHead>
                          <TableHead>Percentage</TableHead>
                          <TableHead>Grade</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {section2Results.length > 0 ? (
                          section2Results.map((result) => (
                            <TableRow key={result.id}>
                              <TableCell>{result.id}</TableCell>
                              <TableCell>{result.studentName}</TableCell>
                              <TableCell>{result.email}</TableCell>
                              <TableCell>{result.score}</TableCell>
                              <TableCell>{result.totalQuestions}</TableCell>
                              <TableCell>{result.percentage}%</TableCell>
                              <TableCell>{getPercentageBadge(result.percentage)}</TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                              No results for Section 2 yet
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                <TabsContent value="section3">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Student Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Score</TableHead>
                          <TableHead>Total Questions</TableHead>
                          <TableHead>Percentage</TableHead>
                          <TableHead>Grade</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {section3Results.length > 0 ? (
                          section3Results.map((result) => (
                            <TableRow key={result.id}>
                              <TableCell>{result.id}</TableCell>
                              <TableCell>{result.studentName}</TableCell>
                              <TableCell>{result.email}</TableCell>
                              <TableCell>{result.score}</TableCell>
                              <TableCell>{result.totalQuestions}</TableCell>
                              <TableCell>{result.percentage}%</TableCell>
                              <TableCell>{getPercentageBadge(result.percentage)}</TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                              No results for Section 3 yet
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                <TabsContent value="section4">
                  <div className="rounded-lg border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Student Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Score</TableHead>
                          <TableHead>Total Questions</TableHead>
                          <TableHead>Percentage</TableHead>
                          <TableHead>Grade</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {section4Results.length > 0 ? (
                          section4Results.map((result) => (
                            <TableRow key={result.id}>
                              <TableCell>{result.id}</TableCell>
                              <TableCell>{result.studentName}</TableCell>
                              <TableCell>{result.email}</TableCell>
                              <TableCell>{result.score}</TableCell>
                              <TableCell>{result.totalQuestions}</TableCell>
                              <TableCell>{result.percentage}%</TableCell>
                              <TableCell>{getPercentageBadge(result.percentage)}</TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                              No results for Section 4 yet
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
