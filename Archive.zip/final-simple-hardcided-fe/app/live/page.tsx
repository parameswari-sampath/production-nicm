"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Loader2 } from "lucide-react";
import { IconInnerShadowTop, IconAlertCircle } from "@tabler/icons-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { liveApi } from "@/lib/api";

function LiveContent() {
  const searchParams = useSearchParams();
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isVerifying, setIsVerifying] = useState(true);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Token verification
  useEffect(() => {
    const verifyToken = async () => {
      const token = searchParams.get("token");

      if (!token) {
        setError("No token provided");
        setIsVerifying(false);
        return;
      }

      // Check if already verified
      const verified = sessionStorage.getItem("token_verified");
      if (verified === token) {
        const cachedUrl = sessionStorage.getItem("video_url");
        if (cachedUrl) {
          setVideoUrl(cachedUrl);
          setIsVerifying(false);
          return;
        }
      }

      try {
        const response = await liveApi.verifyToken(token);
        if (response.success && response.video_url) {
          setVideoUrl(response.video_url);
          sessionStorage.setItem("token_verified", token);
          sessionStorage.setItem("video_url", response.video_url);
        } else {
          setError("Failed to verify token");
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to verify token");
      } finally {
        setIsVerifying(false);
      }
    };

    verifyToken();
  }, [searchParams]);

  // Fullscreen detection
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);

    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, []);

  // Extract YouTube video ID from URL
  const getYouTubeVideoId = (url: string): string | null => {
    try {
      const urlObj = new URL(url);

      // Handle youtube.com/watch?v=
      if (urlObj.hostname.includes("youtube.com") && urlObj.pathname === "/watch") {
        return urlObj.searchParams.get("v");
      }

      // Handle youtu.be/
      if (urlObj.hostname === "youtu.be") {
        return urlObj.pathname.slice(1);
      }

      // Handle youtube.com/shorts/
      if (urlObj.hostname.includes("youtube.com") && urlObj.pathname.startsWith("/shorts/")) {
        return urlObj.pathname.split("/shorts/")[1];
      }

      return null;
    } catch {
      return null;
    }
  };

  const videoId = videoUrl ? getYouTubeVideoId(videoUrl) : null;

  // Header Component
  const LiveHeader = () => (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-14 items-center justify-between px-4 md:px-6">
        <div className="flex items-center gap-2">
          <IconInnerShadowTop className="size-5 text-primary" />
          <span className="font-semibold">SmartMCQ</span>
        </div>
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">
            student@example.com
          </span>
        </div>
      </div>
    </header>
  );

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col">
      <LiveHeader />
      <div className="flex-1 p-4 overflow-auto flex items-center justify-center">
        <div className="max-w-6xl w-full space-y-4">
          {isVerifying ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-20">
                <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
                <p className="text-lg font-semibold">Verifying token...</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Please wait while we verify your access
                </p>
              </CardContent>
            </Card>
          ) : error ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-20">
                <IconAlertCircle className="h-12 w-12 text-destructive mb-4" />
                <p className="text-lg font-semibold">Verification Failed</p>
                <p className="text-sm text-muted-foreground mt-2">{error}</p>
              </CardContent>
            </Card>
          ) : videoId ? (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl">Live Session</CardTitle>
                    <CardDescription className="mt-2">
                      Watch the live conference session
                    </CardDescription>
                  </div>
                  <Badge
                    variant="secondary"
                    className="bg-red-500 text-white animate-pulse"
                  >
                    LIVE
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {!isFullscreen && (
                  <Alert>
                    <IconAlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      For the best viewing experience, we recommend entering
                      fullscreen mode.
                    </AlertDescription>
                  </Alert>
                )}

                <div
                  className="relative w-full"
                  style={{ paddingBottom: "56.25%" }}
                >
                  <iframe
                    className="absolute top-0 left-0 w-full h-full rounded-lg"
                    src={`https://www.youtube.com/embed/${videoId}?autoplay=1&controls=1&modestbranding=1&rel=0`}
                    title="Live Session"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>

                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Session Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Duration</p>
                      <p className="font-semibold">2 Hours</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Topic</p>
                      <p className="font-semibold">Cooperative Development</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Speaker</p>
                      <p className="font-semibold">Dev. Dharani Gowtham</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Status</p>
                      <p className="font-semibold text-red-500">Live Now</p>
                    </div>
                  </div>
                </div>

                <Alert>
                  <IconAlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Please ensure you have a stable internet connection for
                    uninterrupted viewing.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-20">
                <IconAlertCircle className="h-12 w-12 text-destructive mb-4" />
                <p className="text-lg font-semibold">Invalid Video URL</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Unable to extract video from the provided URL
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

export default function LivePage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-muted/30 flex flex-col">
          <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="flex h-14 items-center justify-between px-4 md:px-6">
              <div className="flex items-center gap-2">
                <IconInnerShadowTop className="size-5 text-primary" />
                <span className="font-semibold">SmartMCQ</span>
              </div>
            </div>
          </header>
          <div className="flex-1 flex items-center justify-center p-4">
            <Card className="max-w-md w-full">
              <CardContent className="flex flex-col items-center justify-center py-20">
                <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
                <p className="text-lg font-semibold">Loading...</p>
              </CardContent>
            </Card>
          </div>
        </div>
      }
    >
      <LiveContent />
    </Suspense>
  );
}
