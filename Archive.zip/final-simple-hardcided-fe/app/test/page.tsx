'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { User } from "lucide-react";
import {
  IconAlertCircle,
  IconClock,
  IconCheckupList,
  IconArrowRight,
  IconCircleCheck,
  IconInnerShadowTop,
  IconMaximize
} from "@tabler/icons-react";
import { toast } from "sonner";
import questionsData from "@/questions_with_timer.json";
import Cookies from "js-cookie";
import { sessionApi, answerApi, testApi } from "@/lib/api";

type Question = {
  id: number;
  question: string;
  description: string;
  options: string[];
  correctAnswer: number;
};

type Section = {
  id: number;
  name: string;
  time_limit: number;
  questions: Question[];
};

type TestState = 'rules' | 'in-progress' | 'completed' | 'banned';

export default function TestPage() {
  const router = useRouter();
  const [testState, setTestState] = useState<TestState>('rules');
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [timeRemaining, setTimeRemaining] = useState(-1); // -1 means not initialized
  const [agreedToRules, setAgreedToRules] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [userEmail, setUserEmail] = useState<string>('');
  const [isStartingSession, setIsStartingSession] = useState(false);
  const [questionTimer, setQuestionTimer] = useState(0); // Hidden timer for each question (counts up)
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [testResults, setTestResults] = useState<{
    score: number;
    total_time_taken_seconds: number;
    total_questions_answered: number;
  } | null>(null);
  const [isEndingSession, setIsEndingSession] = useState(false);

  const handleBan = useCallback(() => {
    // Delete all session cookies
    Cookies.remove('session_token');
    Cookies.remove('user_email');
    Cookies.remove('user_name');

    setTestState('banned');
    toast.error('Account banned due to suspicious activity');
  }, []);

  // Get user email from cookie
  useEffect(() => {
    const email = Cookies.get('user_email') || '';
    setUserEmail(email);
  }, []);

  // Detect ESC key press
  useEffect(() => {
    if (testState !== 'in-progress') return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        handleBan();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [testState, handleBan]);

  // Detect copy/paste operations
  useEffect(() => {
    if (testState !== 'in-progress') return;

    const handleCopy = (e: ClipboardEvent) => {
      e.preventDefault();
      handleBan();
    };

    const handlePaste = (e: ClipboardEvent) => {
      e.preventDefault();
      handleBan();
    };

    document.addEventListener('copy', handleCopy);
    document.addEventListener('paste', handlePaste);
    document.addEventListener('cut', handleCopy);

    return () => {
      document.removeEventListener('copy', handleCopy);
      document.removeEventListener('paste', handlePaste);
      document.removeEventListener('cut', handleCopy);
    };
  }, [testState, handleBan]);

  // Detect cookie deletion (session monitoring)
  useEffect(() => {
    if (testState !== 'in-progress') return;

    const interval = setInterval(() => {
      const sessionToken = Cookies.get('session_token');
      if (!sessionToken) {
        handleBan();
      }
    }, 1000); // Check every second

    return () => clearInterval(interval);
  }, [testState, handleBan]);

  // Detect fullscreen exit
  useEffect(() => {
    if (testState !== 'in-progress') return;

    const handleFullscreenChange = () => {
      if (!document.fullscreenElement) {
        // User exited fullscreen
        handleBan();
      }
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, [testState, handleBan]);

  // Detect tab switch / focus loss
  useEffect(() => {
    if (testState !== 'in-progress') return;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        // User switched tabs or minimized window
        handleBan();
      }
    };

    const handleBlur = () => {
      // Window lost focus
      handleBan();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleBlur);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleBlur);
    };
  }, [testState, handleBan]);

  const sections: Section[] = questionsData as Section[];
  const currentSection = sections[currentSectionIndex];
  const currentQuestion = currentSection?.questions[currentQuestionIndex];
  const totalSections = sections.length;
  const totalQuestionsInSection = currentSection?.questions.length || 0;
  const progress = ((currentQuestionIndex + 1) / totalQuestionsInSection) * 100;

  // Section completion handler
  const handleSectionComplete = useCallback(async () => {
    if (currentSectionIndex < totalSections - 1) {
      // Move to next section
      setCurrentSectionIndex(prev => prev + 1);
      setCurrentQuestionIndex(0);
      setSelectedAnswer(null);
    } else {
      // Test completed - call end session API
      const sessionToken = Cookies.get('session_token');
      if (!sessionToken) {
        toast.error('Session token not found');
        setTestState('completed');
        return;
      }

      setIsEndingSession(true);
      try {
        const response = await testApi.endSession(sessionToken);
        setTestResults({
          score: response.score,
          total_time_taken_seconds: response.total_time_taken_seconds,
          total_questions_answered: response.total_questions_answered,
        });

        // Clear all cookies
        Cookies.remove('session_token');
        Cookies.remove('user_email');
        Cookies.remove('user_name');

        setTestState('completed');
        toast.success('Test completed successfully!');
      } catch (error) {
        toast.error(error instanceof Error ? error.message : 'Failed to end session');
        setTestState('completed');
      } finally {
        setIsEndingSession(false);
      }
    }
  }, [currentSectionIndex, totalSections]);

  // Timer effect
  useEffect(() => {
    if (testState !== 'in-progress' || timeRemaining < 0) return;

    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [testState, timeRemaining]);

  // Handle timer expiry
  useEffect(() => {
    if (testState === 'in-progress' && timeRemaining === 0 && !isTransitioning) {
      setIsTransitioning(true);
      handleSectionComplete();
    }
  }, [timeRemaining, testState, isTransitioning, handleSectionComplete]);

  // Initialize timer when starting test or moving to new section
  useEffect(() => {
    if (testState === 'in-progress' && currentSection) {
      setTimeRemaining(currentSection.time_limit);
      setIsTransitioning(false);
    }
  }, [currentSectionIndex, testState, currentSection]);

  // Question timer - counts up for each question
  useEffect(() => {
    if (testState !== 'in-progress') return;

    const timer = setInterval(() => {
      setQuestionTimer(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [testState, currentQuestionIndex, currentSectionIndex]); // Reset when question/section changes

  // Reset question timer when question changes
  useEffect(() => {
    setQuestionTimer(0);
  }, [currentQuestionIndex, currentSectionIndex]);

  // Disable copy/paste
  useEffect(() => {
    const handleCopyPaste = (e: ClipboardEvent) => {
      e.preventDefault();
      toast.warning('Copy/Paste disabled during the test', {
        description: "Please do not attempt to copy or paste during the test.",
        duration: 4000,
      });
    };

    if (testState === 'in-progress') {
      document.addEventListener('copy', handleCopyPaste);
      document.addEventListener('cut', handleCopyPaste);
      document.addEventListener('paste', handleCopyPaste);

      return () => {
        document.removeEventListener('copy', handleCopyPaste);
        document.removeEventListener('cut', handleCopyPaste);
        document.removeEventListener('paste', handleCopyPaste);
      };
    }
  }, [testState]);

  // Fullscreen detection
  useEffect(() => {
    const handleFullscreenChange = () => {
      const inFullscreen = !!document.fullscreenElement;
      setIsFullscreen(inFullscreen);

      // If user exits fullscreen during test, show warning
      if (!inFullscreen && testState === 'in-progress') {
        toast.error('Fullscreen mode exited!', {
          description: 'You must return to fullscreen mode to continue the test.',
          duration: Infinity,
          id: 'fullscreen-warning',
        });
      } else if (inFullscreen && testState === 'in-progress') {
        // Dismiss the toast when returning to fullscreen
        toast.dismiss('fullscreen-warning');
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, [testState]);

  const enterFullscreen = async () => {
    try {
      await document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } catch {
      toast.error('Failed to enter fullscreen mode', {
        description: 'Please allow fullscreen access to continue the test.',
      });
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartTest = async () => {
    if (!isFullscreen) {
      toast.warning('Please enter fullscreen mode to start the test');
      return;
    }

    const sessionToken = Cookies.get('session_token');
    if (!sessionToken) {
      toast.error('Session token not found. Please login again.');
      return;
    }

    setIsStartingSession(true);
    try {
      const response = await sessionApi.startSession(sessionToken);
      toast.success(response.message);

      // Start the test
      setCurrentSectionIndex(0);
      setCurrentQuestionIndex(0);
      setSelectedAnswer(null);
      setIsTransitioning(false);
      setTestState('in-progress');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to start session');
    } finally {
      setIsStartingSession(false);
    }
  };

  const handleNextQuestion = async () => {
    if (selectedAnswer === null) return;

    const sessionToken = Cookies.get('session_token');
    if (!sessionToken) {
      toast.error('Session expired. Please login again.');
      handleBan();
      return;
    }

    setIsSubmitting(true);

    try {
      // Calculate if answer is correct
      const isCorrect = selectedAnswer === currentQuestion.correctAnswer;

      // Submit answer to API
      await answerApi.submitAnswer({
        session_token: sessionToken,
        question_id: currentQuestion.id,
        selected_option_index: selectedAnswer,
        is_correct: isCorrect,
        time_taken_seconds: questionTimer,
      });

      // Move to next question or complete section
      if (currentQuestionIndex < totalQuestionsInSection - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
        setSelectedAnswer(null);
      } else {
        handleSectionComplete();
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to submit answer');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Header Component
  const TestHeader = () => (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-14 items-center justify-between px-4 md:px-6">
        <div className="flex items-center gap-2">
          <IconInnerShadowTop className="size-5 text-primary" />
          <span className="font-semibold">SmartMCQ</span>
        </div>
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">{userEmail}</span>
        </div>
      </div>
    </header>
  );

  // Banned Page
  if (testState === 'banned') {
    return (
      <div className="min-h-screen bg-muted/30 flex flex-col">
        <TestHeader />
        <div className="flex-1 flex items-center justify-center p-4">
          <Card className="max-w-2xl w-full">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="bg-destructive/10 p-4 rounded-full">
                  <IconAlertCircle className="h-12 w-12 text-destructive" />
                </div>
              </div>
              <CardTitle className="text-3xl text-destructive">Account Banned</CardTitle>
              <CardDescription className="text-base mt-4">
                Your account has been banned due to suspicious activity during the test.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert variant="destructive">
                <IconAlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Detected violations:
                  <ul className="list-disc list-inside mt-2 space-y-1">
                    <li>Attempting to exit fullscreen mode (ESC key)</li>
                    <li>Copy/paste operations during test</li>
                    <li>Session tampering or cookie manipulation</li>
                  </ul>
                </AlertDescription>
              </Alert>

              <div className="bg-muted p-4 rounded-lg">
                <p className="text-sm font-semibold mb-2">What this means:</p>
                <p className="text-sm text-muted-foreground">
                  Your test session has been terminated and your responses will not be recorded.
                  Please contact the administrator if you believe this was a mistake.
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                size="lg"
                className="w-full"
                onClick={() => router.push('/')}
              >
                Return to Home
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    );
  }

  // Rules Page
  if (testState === 'rules') {
    return (
      <div className="min-h-screen bg-muted/30 flex flex-col">
        <TestHeader />
        <div className="flex-1 flex items-center justify-center p-4">
          <Card className="max-w-3xl w-full">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <IconCheckupList className="h-6 w-6 text-primary" />
              <CardTitle className="text-2xl">Test Instructions & Rules</CardTitle>
            </div>
            <CardDescription>
              Please read the following instructions carefully before starting the test
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Badge variant="outline" className="mt-1">1</Badge>
                <div>
                  <h3 className="font-semibold mb-1">Test Structure</h3>
                  <p className="text-sm text-muted-foreground">
                    This test consists of <strong>4 sections</strong> with <strong>30 questions each</strong>.
                    Each section covers different topics related to cooperatives.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Badge variant="outline" className="mt-1">2</Badge>
                <div>
                  <h3 className="font-semibold mb-1">Time Limit</h3>
                  <p className="text-sm text-muted-foreground">
                    Each section has a time limit of <strong>15 minutes (900 seconds)</strong>.
                    The timer will automatically submit your answers when time runs out.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Badge variant="outline" className="mt-1">3</Badge>
                <div>
                  <h3 className="font-semibold mb-1">Navigation</h3>
                  <p className="text-sm text-muted-foreground">
                    You can only move <strong>forward</strong> through questions.
                    Once you proceed to the next question, you <strong>cannot go back</strong> to change your answer.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Badge variant="outline" className="mt-1">4</Badge>
                <div>
                  <h3 className="font-semibold mb-1">Answering Questions</h3>
                  <p className="text-sm text-muted-foreground">
                    Select one option for each question. You must select an answer before proceeding to the next question.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Badge variant="outline" className="mt-1">5</Badge>
                <div>
                  <h3 className="font-semibold mb-1">Section Transitions</h3>
                  <p className="text-sm text-muted-foreground">
                    After completing all questions in a section, you will automatically move to the next section.
                    The timer will reset for each new section.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Badge variant="outline" className="mt-1">6</Badge>
                <div>
                  <h3 className="font-semibold mb-1">Important Reminders</h3>
                  <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1">
                    <li>Ensure stable internet connection throughout the test</li>
                    <li>Do not refresh or close the browser window</li>
                    <li>Find a quiet place with minimal distractions</li>
                    <li>Keep track of time for each section</li>
                  </ul>
                </div>
              </div>
            </div>

            <Separator />

            <Alert>
              <IconAlertCircle className="h-4 w-4" />
              <AlertDescription>
                Once you start the test, the timer will begin immediately. Make sure you are ready before clicking the &quot;Start Test&quot; button below.
              </AlertDescription>
            </Alert>

            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-semibold mb-2">Test Summary</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Total Sections</p>
                  <p className="font-semibold">4 Sections</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Questions per Section</p>
                  <p className="font-semibold">30 Questions</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Time per Section</p>
                  <p className="font-semibold">15 Minutes</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Total Questions</p>
                  <p className="font-semibold">120 Questions</p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <div className="flex items-center space-x-2 self-start">
              <Checkbox
                id="agree-rules"
                checked={agreedToRules}
                onCheckedChange={(checked) => setAgreedToRules(checked === true)}
              />
              <Label
                htmlFor="agree-rules"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                I have read and understood all the instructions and rules
              </Label>
            </div>

            {!isFullscreen && (
              <Alert>
                <IconAlertCircle className="h-4 w-4" />
                <AlertDescription>
                  You must enter fullscreen mode before starting the test.
                </AlertDescription>
              </Alert>
            )}

            <div className="flex justify-between w-full items-center">
              <p className="text-sm text-muted-foreground">Read all instructions carefully</p>
              <div className="flex gap-2">
                {!isFullscreen && (
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={enterFullscreen}
                  >
                    <IconMaximize className="mr-2 h-4 w-4" />
                    Enter Fullscreen
                  </Button>
                )}
                <Button
                  size="lg"
                  onClick={handleStartTest}
                  disabled={!agreedToRules || !isFullscreen || isStartingSession}
                >
                  {isStartingSession ? "Starting..." : "Start Test"}
                  <IconArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardFooter>
        </Card>
      </div>
      </div>
    );
  }

  // Test In Progress
  if (testState === 'in-progress' && currentQuestion) {
    const isTimeWarning = timeRemaining < 120; // Less than 2 minutes

    // Block overlay when not in fullscreen during test
    if (!isFullscreen) {
      return (
        <div className="min-h-screen bg-muted/30 flex flex-col">
          <TestHeader />
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center pt-14">
            <Card className="max-w-md w-full mx-4">
              <CardHeader>
                <div className="flex justify-center mb-4">
                  <div className="bg-destructive/10 p-4 rounded-full">
                    <IconAlertCircle className="h-12 w-12 text-destructive" />
                  </div>
                </div>
                <CardTitle className="text-center text-2xl">Fullscreen Required</CardTitle>
                <CardDescription className="text-center">
                  You exited fullscreen mode. The test is paused.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert variant="destructive">
                  <IconAlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    You must return to fullscreen mode to continue the test. The timer is still running.
                  </AlertDescription>
                </Alert>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button size="lg" onClick={enterFullscreen}>
                  <IconMaximize className="mr-2 h-4 w-4" />
                  Return to Fullscreen
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-muted/30 flex flex-col">
        <TestHeader />
        <div className="flex-1 p-4 overflow-auto flex items-center justify-center">
          <div className="max-w-4xl w-full space-y-4">
          {/* Header */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <Badge variant="secondary" className="mb-2">
                    {currentSection.name}
                  </Badge>
                  <p className="text-sm text-muted-foreground">
                    Question {currentQuestionIndex + 1} of {totalQuestionsInSection}
                  </p>
                </div>
                <div className="text-right">
                  <div className={`flex items-center gap-2 ${isTimeWarning ? 'text-destructive' : ''}`}>
                    <IconClock className="h-5 w-5" />
                    <span className="text-2xl font-bold font-mono">
                      {formatTime(timeRemaining)}
                    </span>
                  </div>
                  {isTimeWarning && (
                    <p className="text-xs text-destructive mt-1">Time running out!</p>
                  )}
                </div>
              </div>
              <Progress value={progress} className="h-2" />
            </CardContent>
          </Card>

          {/* Question Card */}
          <Card>
            <CardHeader>
              <CardDescription className="text-xs uppercase tracking-wide">
                {currentQuestion.description}
              </CardDescription>
              <CardTitle className="text-xl leading-relaxed">
                {currentQuestion.question}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <RadioGroup
                value={selectedAnswer?.toString()}
                onValueChange={(value) => setSelectedAnswer(parseInt(value))}
              >
                {currentQuestion.options.map((option, index) => (
                  <div key={index}>
                    <div
                      className={`flex items-center space-x-3 border rounded-lg p-4 cursor-pointer transition-all hover:bg-muted ${
                        selectedAnswer === index ? 'border-primary bg-primary/5' : ''
                      }`}
                      onClick={() => setSelectedAnswer(index)}
                    >
                      <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                      <Label
                        htmlFor={`option-${index}`}
                        className="flex-1 cursor-pointer font-normal"
                      >
                        {option}
                      </Label>
                    </div>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-sm text-muted-foreground">
                {selectedAnswer !== null ? (
                  <span className="flex items-center gap-1 text-primary">
                    <IconCircleCheck className="h-4 w-4" />
                    Answer selected
                  </span>
                ) : (
                  'Select an answer to continue'
                )}
              </div>
              <Button
                size="lg"
                onClick={handleNextQuestion}
                disabled={selectedAnswer === null || isSubmitting}
              >
                {isSubmitting ? 'Submitting...' : (currentQuestionIndex < totalQuestionsInSection - 1 ? 'Next Question' : 'Complete Section')}
                <IconArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
      </div>
    );
  }

  // Test Completed
  if (testState === 'completed') {
    const totalQuestions = sections.reduce((sum, section) => sum + section.questions.length, 0);

    const formatTestTime = (seconds: number) => {
      const hours = Math.floor(seconds / 3600);
      const mins = Math.floor((seconds % 3600) / 60);
      const secs = seconds % 60;

      if (hours > 0) {
        return `${hours}h ${mins}m ${secs}s`;
      } else if (mins > 0) {
        return `${mins}m ${secs}s`;
      } else {
        return `${secs}s`;
      }
    };

    return (
      <div className="min-h-screen bg-muted/30 flex flex-col">
        <TestHeader />
        <div className="flex-1 flex items-center justify-center p-4">
          <Card className="max-w-2xl w-full">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="bg-primary/10 p-4 rounded-full">
                <IconCircleCheck className="h-12 w-12 text-primary" />
              </div>
            </div>
            <CardTitle className="text-3xl">Test Completed!</CardTitle>
            <CardDescription>
              You have successfully completed all sections of the test
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {isEndingSession ? (
              <div className="bg-muted p-6 rounded-lg text-center">
                <p className="text-muted-foreground">Calculating your results...</p>
              </div>
            ) : testResults ? (
              <>
                <div className="bg-muted p-6 rounded-lg space-y-4">
                  <h3 className="font-semibold text-lg">Your Results</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Score</p>
                      <p className="text-3xl font-bold text-primary">{testResults.score}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Total Time</p>
                      <p className="text-2xl font-bold">{formatTestTime(testResults.total_time_taken_seconds)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Questions Answered</p>
                      <p className="text-2xl font-bold">{testResults.total_questions_answered}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Accuracy</p>
                      <p className="text-2xl font-bold">
                        {testResults.total_questions_answered > 0
                          ? ((testResults.score / testResults.total_questions_answered) * 100).toFixed(1)
                          : '0'}%
                      </p>
                    </div>
                  </div>
                </div>

                <Alert>
                  <IconAlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Your test has been submitted successfully. The detailed results have been recorded.
                  </AlertDescription>
                </Alert>
              </>
            ) : (
              <div className="bg-muted p-6 rounded-lg space-y-4">
                <h3 className="font-semibold text-lg">Test Summary</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Sections Completed</p>
                    <p className="text-2xl font-bold">{totalSections}/{totalSections}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Total Questions</p>
                    <p className="text-2xl font-bold">{totalQuestions}</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex gap-3 justify-center">
            <Button size="lg" variant="outline" onClick={() => window.location.href = `/report?email=${encodeURIComponent(userEmail)}`}>
              View Detailed Report
            </Button>
            <Button size="lg" onClick={() => window.location.href = '/'}>
              Return to Home
            </Button>
          </CardFooter>
        </Card>
      </div>
      </div>
    );
  }

  return null;
}
