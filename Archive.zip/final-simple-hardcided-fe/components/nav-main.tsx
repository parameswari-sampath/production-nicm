"use client"

import { useState } from "react"
import { type Icon, IconPlayerPlay } from "@tabler/icons-react"
import { ChevronDownIcon } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { eventApi } from "@/lib/api"
import { toast } from "sonner"

export function NavMain({
  items,
}: {
  items: {
    title: string
    url: string
    icon?: Icon
  }[]
}) {
  const pathname = usePathname()
  const [isLiveModalOpen, setIsLiveModalOpen] = useState(false)
  const [conferencePopoverOpen, setConferencePopoverOpen] = useState(false)
  const [conferenceDate, setConferenceDate] = useState<Date | undefined>(new Date())
  const [conferenceTime, setConferenceTime] = useState(new Date().toTimeString().slice(0, 8))
  const [testPopoverOpen, setTestPopoverOpen] = useState(false)
  const [testDate, setTestDate] = useState<Date | undefined>(new Date())
  const [testTime, setTestTime] = useState(new Date().toTimeString().slice(0, 8))
  const [videoUrl, setVideoUrl] = useState("")
  const [isCreating, setIsCreating] = useState(false)

  const formatToIST = (date: Date | undefined, time: string): string => {
    if (!date) return ""

    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')

    return `${year}-${month}-${day}T${time}`
  }

  const handleStartLive = async () => {
    if (!videoUrl) {
      toast.error("Please enter the conference link")
      return
    }

    if (!conferenceDate || !testDate) {
      toast.error("Please select both conference and test dates")
      return
    }

    const firstScheduledTime = formatToIST(conferenceDate, conferenceTime)
    const secondScheduledTime = formatToIST(testDate, testTime)

    // Validate that second time is after first time
    if (new Date(secondScheduledTime) <= new Date(firstScheduledTime)) {
      toast.error("Test time must be after conference time")
      return
    }

    setIsCreating(true)
    try {
      const response = await eventApi.createSchedule({
        first_scheduled_time: firstScheduledTime,
        second_scheduled_time: secondScheduledTime,
        video_url: videoUrl,
      })

      toast.success(response.message)
      setIsLiveModalOpen(false)
      // Reset form
      setVideoUrl("")
      setConferenceDate(new Date())
      setConferenceTime(new Date().toTimeString().slice(0, 8))
      setTestDate(new Date())
      setTestTime(new Date().toTimeString().slice(0, 8))
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to create schedule")
    } finally {
      setIsCreating(false)
    }
  }

  return (
    <SidebarGroup>
      <SidebarGroupContent className="flex flex-col gap-2">
        <SidebarMenu>
          <SidebarMenuItem>
            <Dialog open={isLiveModalOpen} onOpenChange={setIsLiveModalOpen}>
              <DialogTrigger asChild>
                <SidebarMenuButton
                  tooltip="Start Live"
                  className="bg-red-500 text-white hover:bg-red-600 hover:text-white"
                >
                  <IconPlayerPlay />
                  <span>Start Live</span>
                </SidebarMenuButton>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Start Live Session</DialogTitle>
                  <DialogDescription>
                    Configure conference and test timings to start the live session
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="grid gap-3">
                    <Label htmlFor="conference-link">Conference Link</Label>
                    <Input
                      id="conference-link"
                      type="url"
                      placeholder="https://www.youtube.com/shorts/..."
                      value={videoUrl}
                      onChange={(e) => setVideoUrl(e.target.value)}
                      required
                    />
                  </div>
                  <div className="grid gap-3">
                    <Label className="px-1">Conference Starting Date & Time</Label>
                    <div className="flex gap-4 w-full">
                      <div className="flex flex-col gap-3 flex-1">
                        <Popover open={conferencePopoverOpen} onOpenChange={setConferencePopoverOpen}>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className="w-full justify-between font-normal"
                            >
                              {conferenceDate ? conferenceDate.toLocaleDateString() : "Select date"}
                              <ChevronDownIcon />
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto overflow-hidden p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={conferenceDate}
                              captionLayout="dropdown"
                              onSelect={(date) => {
                                setConferenceDate(date)
                                setConferencePopoverOpen(false)
                              }}
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                      <div className="flex flex-col gap-3 flex-1">
                        <Input
                          type="time"
                          step="1"
                          value={conferenceTime}
                          onChange={(e) => setConferenceTime(e.target.value)}
                          className="bg-background w-full appearance-none [&::-webkit-calendar-picker-indicator]:hidden [&::-webkit-calendar-picker-indicator]:appearance-none"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="grid gap-3">
                    <Label className="px-1">Test Starting Date & Time</Label>
                    <div className="flex gap-4 w-full">
                      <div className="flex flex-col gap-3 flex-1">
                        <Popover open={testPopoverOpen} onOpenChange={setTestPopoverOpen}>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className="w-full justify-between font-normal"
                            >
                              {testDate ? testDate.toLocaleDateString() : "Select date"}
                              <ChevronDownIcon />
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto overflow-hidden p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={testDate}
                              captionLayout="dropdown"
                              onSelect={(date) => {
                                setTestDate(date)
                                setTestPopoverOpen(false)
                              }}
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                      <div className="flex flex-col gap-3 flex-1">
                        <Input
                          type="time"
                          step="1"
                          value={testTime}
                          onChange={(e) => setTestTime(e.target.value)}
                          className="bg-background w-full appearance-none [&::-webkit-calendar-picker-indicator]:hidden [&::-webkit-calendar-picker-indicator]:appearance-none"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    className="w-full bg-red-500 hover:bg-red-600"
                    onClick={handleStartLive}
                    disabled={isCreating}
                  >
                    <IconPlayerPlay className="mr-2 size-4" />
                    {isCreating ? "Creating Schedule..." : "Start"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </SidebarMenuItem>
        </SidebarMenu>
        <SidebarMenu>
          {items.map((item) => (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton tooltip={item.title} asChild isActive={pathname === item.url}>
                <Link href={item.url}>
                  {item.icon && <item.icon />}
                  <span>{item.title}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  )
}
