const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';

export interface Student {
  id: number;
  name: string;
  email: string;
  created_at?: string;
  updated_at?: string;
}

export interface AddStudentRequest {
  name: string;
  email: string;
}

export interface UpdateStudentRequest {
  name: string;
  email: string;
}

export interface BulkCreateStudentsRequest {
  students: Array<{
    name: string;
    email: string;
  }>;
}

export interface BulkCreateStudentsResponse {
  message: string;
  count?: number;
  success?: number;
  failed?: number;
  duplicates?: string[];
}

export interface GetStudentsResponse {
  students: Student[];
  total: number;
  limit: number;
  offset: number;
  count: number;
}

export const studentsApi = {
  async getAllStudents(limit: number = 10, offset: number = 0): Promise<GetStudentsResponse> {
    const response = await fetch(`${API_BASE_URL}/api/students?limit=${limit}&offset=${offset}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch students: ${response.statusText}`);
    }

    const data: GetStudentsResponse = await response.json();
    return data;
  },

  async getStudentById(id: number): Promise<Student> {
    const response = await fetch(`${API_BASE_URL}/api/students/${id}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch student: ${response.statusText}`);
    }

    return response.json();
  },

  async addStudent(data: AddStudentRequest): Promise<Student> {
    const response = await fetch(`${API_BASE_URL}/api/students`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || `Failed to add student: ${response.statusText}`);
    }

    return response.json();
  },

  async updateStudent(id: number, data: UpdateStudentRequest): Promise<Student> {
    const response = await fetch(`${API_BASE_URL}/api/students/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`Failed to update student: ${response.statusText}`);
    }

    return response.json();
  },

  async deleteStudent(id: number): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/api/students/${id}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      throw new Error(`Failed to delete student: ${response.statusText}`);
    }
  },

  async bulkCreateStudents(data: BulkCreateStudentsRequest): Promise<BulkCreateStudentsResponse> {
    const response = await fetch(`${API_BASE_URL}/api/students/bulk`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || `Failed to bulk create students: ${response.statusText}`);
    }

    return response.json();
  },
};

export interface ResetDatabaseResponse {
  message: string;
  status: string;
}

export const adminApi = {
  async resetDatabase(): Promise<ResetDatabaseResponse> {
    const response = await fetch(`${API_BASE_URL}/api/admin/reset-db`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to reset database: ${response.statusText}`);
    }

    return response.json();
  },
};

export interface EmailStatsResponse {
  total_emails: number;
}

export interface SearchEmailResponse {
  count?: number;
  emails?: string[];
  error?: string;
}

export interface SendEmailToAllRequest {
  subject: string;
  html_body: string;
}

export interface SendEmailToAllResponse {
  message: string;
  total: number;
  sent: number;
}

export interface EmailLog {
  id: number;
  student_id: number;
  email: string;
  subject: string;
  status: string;
  request_id: string;
  response_code: string;
  response_message: string;
  sent_at: string;
}

export interface EmailLogsResponse {
  count: number;
  logs: EmailLog[];
}

export const mailApi = {
  async getEmailStats(): Promise<EmailStatsResponse> {
    const response = await fetch(`${API_BASE_URL}/api/mail/stats`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch email stats: ${response.statusText}`);
    }

    return response.json();
  },

  async searchEmail(email: string): Promise<SearchEmailResponse> {
    const response = await fetch(`${API_BASE_URL}/api/mail/search?email=${encodeURIComponent(email)}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok && response.status !== 404) {
      throw new Error(`Failed to search email: ${response.statusText}`);
    }

    return response.json();
  },

  async sendToAll(data: SendEmailToAllRequest): Promise<SendEmailToAllResponse> {
    const response = await fetch(`${API_BASE_URL}/api/mail/send-all`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || `Failed to send emails: ${response.statusText}`);
    }

    return response.json();
  },

  async getEmailLogs(status: 'sent' | 'bounced' | 'failed' = 'sent'): Promise<EmailLogsResponse> {
    const response = await fetch(`${API_BASE_URL}/api/mail/logs?status=${status}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch email logs: ${response.statusText}`);
    }

    return response.json();
  },
};

export interface VerifyTokenRequest {
  token: string;
}

export interface VerifyTokenResponse {
  success: boolean;
  video_url: string;
  message: string;
}

export const liveApi = {
  async verifyToken(token: string): Promise<VerifyTokenResponse> {
    const response = await fetch(`${API_BASE_URL}/api/live/verify-first-mail`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ token }),
    });

    if (!response.ok) {
      throw new Error(`Failed to verify token: ${response.statusText}`);
    }

    return response.json();
  },
};

export interface CreateScheduleRequest {
  first_scheduled_time: string;
  second_scheduled_time: string;
  video_url: string;
}

export interface CreateScheduleResponse {
  message: string;
  schedule_id: number;
  first_function: string;
  first_scheduled_time: string;
  second_function: string;
  second_scheduled_time: string;
  video_url: string;
}

export const eventApi = {
  async createSchedule(data: CreateScheduleRequest): Promise<CreateScheduleResponse> {
    const response = await fetch(`${API_BASE_URL}/api/event/schedule`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || `Failed to create schedule: ${response.statusText}`);
    }

    return response.json();
  },
};

export interface VerifyOTPRequest {
  OTP: string;
}

export interface VerifyOTPResponse {
  success: boolean;
  session_token?: string;
  email?: string;
  name?: string;
  message: string;
}

export const otpApi = {
  async verifyOTP(otp: string): Promise<VerifyOTPResponse> {
    const response = await fetch(`${API_BASE_URL}/api/live/verify-otp`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ OTP: otp }),
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Failed to verify OTP');
    }

    return data;
  },
};

export interface StartSessionRequest {
  session_token: string;
}

export interface StartSessionResponse {
  success: boolean;
  message: string;
}

export const sessionApi = {
  async startSession(sessionToken: string): Promise<StartSessionResponse> {
    const response = await fetch(`${API_BASE_URL}/api/live/start-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ session_token: sessionToken }),
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Failed to start session');
    }

    return data;
  },
};

export interface SubmitAnswerRequest {
  session_token: string;
  question_id: number;
  selected_option_index: number;
  is_correct: boolean;
  time_taken_seconds: number;
}

export interface SubmitAnswerResponse {
  success: boolean;
  message: string;
}

export const answerApi = {
  async submitAnswer(data: SubmitAnswerRequest): Promise<SubmitAnswerResponse> {
    const response = await fetch(`${API_BASE_URL}/api/live/submit-answer`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (!response.ok || !result.success) {
      throw new Error(result.message || 'Failed to submit answer');
    }

    return result;
  },
};

export interface EndSessionRequest {
  session_token: string;
}

export interface EndSessionResponse {
  success: boolean;
  message: string;
  score: number;
  total_time_taken_seconds: number;
  total_questions_answered: number;
}

export interface TestResultRequest {
  email: string;
}

export interface Question {
  id: number;
  question: string;
  description: string;
  options: string[];
  correctAnswer: number;
  selected_answer: number | null;
  is_correct: boolean | null;
  time_taken_seconds: number | null;
}

export interface Section {
  id: number;
  name: string;
  time_limit: number;
  questions: Question[];
}

export interface TestResultResponse {
  success: boolean;
  student: {
    name: string;
    email: string;
  };
  session: {
    score: number;
    total_time_taken_seconds: number;
    total_questions_answered: number;
    completed: boolean;
  };
  sections: Section[];
}

export const testApi = {
  async endSession(sessionToken: string): Promise<EndSessionResponse> {
    const response = await fetch(`${API_BASE_URL}/api/live/end-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ session_token: sessionToken }),
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Failed to end session');
    }

    return data;
  },

  async getResult(email: string): Promise<TestResultResponse> {
    const response = await fetch(`${API_BASE_URL}/api/live/result`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Failed to fetch test result');
    }

    return data;
  },
};
