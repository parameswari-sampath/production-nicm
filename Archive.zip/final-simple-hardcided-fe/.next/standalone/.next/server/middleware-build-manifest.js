globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/577ea06e3adddf96.js",
      "static/chunks/8f487db0e2a413ca.js",
      "static/chunks/turbopack-e29f09ac7f021eb4.js"
    ],
    "/_error": [
      "static/chunks/24d7a76c12c96677.js",
      "static/chunks/8f487db0e2a413ca.js",
      "static/chunks/turbopack-0cd4a41de3d30f98.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/7926da499020c43b.js",
    "static/chunks/e743c975ec2f6a19.js",
    "static/chunks/cc12fe0ab08ae788.js",
    "static/chunks/eb9a360d80df2c4b.js",
    "static/chunks/28b964b6306f2e49.js",
    "static/chunks/turbopack-447e5d558f0360f6.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];