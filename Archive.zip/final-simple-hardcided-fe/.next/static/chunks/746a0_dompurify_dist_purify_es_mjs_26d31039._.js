(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/746a0_dompurify_dist_purify_es_mjs_98dbf362._.js"
],
    source: "dynamic"
});
