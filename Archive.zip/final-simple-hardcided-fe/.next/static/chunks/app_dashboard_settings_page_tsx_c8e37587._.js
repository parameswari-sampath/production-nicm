(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_47688d5f._.js",
  "static/chunks/0894d_tailwind-merge_dist_bundle-mjs_mjs_705de4d7._.js",
  "static/chunks/50d1e_date-fns_8a8740ec._.js",
  "static/chunks/64197_react-day-picker_dist_esm_b0a2c5d0._.js",
  "static/chunks/node_modules__pnpm_45eb0013._.js"
],
    source: "dynamic"
});
