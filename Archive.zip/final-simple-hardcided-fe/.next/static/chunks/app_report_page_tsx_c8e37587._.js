(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_65bd1837._.js",
  "static/chunks/_b6a6d535._.js",
  "static/chunks/0894d_tailwind-merge_dist_bundle-mjs_mjs_705de4d7._.js",
  "static/chunks/53b85_pako_dist_pako_esm_mjs_b8ddddf5._.js",
  "static/chunks/c17c6_jspdf_dist_jspdf_es_min_2f6c8fa4.js",
  "static/chunks/node_modules__pnpm_62a4854e._.js"
],
    source: "dynamic"
});
