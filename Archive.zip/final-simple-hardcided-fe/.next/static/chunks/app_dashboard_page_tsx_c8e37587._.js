(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_3f13e99a._.js",
  "static/chunks/0894d_tailwind-merge_dist_bundle-mjs_mjs_705de4d7._.js",
  "static/chunks/50d1e_date-fns_8a8740ec._.js",
  "static/chunks/64197_react-day-picker_dist_esm_b0a2c5d0._.js",
  "static/chunks/b449a_lodash_be326582._.js",
  "static/chunks/dd0d1_recharts_es6_78ad3e74._.js",
  "static/chunks/e68d8_@radix-ui_react-select_dist_index_mjs_e9377de7._.js",
  "static/chunks/node_modules__pnpm_ee43a93b._.js"
],
    source: "dynamic"
});
