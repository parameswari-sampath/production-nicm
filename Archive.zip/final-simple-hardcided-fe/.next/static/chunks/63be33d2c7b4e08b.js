__turbopack_load_page_chunks__("/_error", [
  "static/chunks/24d7a76c12c96677.js",
  "static/chunks/8f487db0e2a413ca.js",
  "static/chunks/turbopack-0cd4a41de3d30f98.js"
])
