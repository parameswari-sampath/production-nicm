(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_be2445a1._.js",
  "static/chunks/f7813_next_dist_compiled_react-dom_8262c337._.js",
  "static/chunks/f7813_next_dist_compiled_next-devtools_index_a13d571c.js",
  "static/chunks/f7813_next_dist_compiled_2235c785._.js",
  "static/chunks/f7813_next_dist_client_7d63aa88._.js",
  "static/chunks/f7813_next_dist_55b9482d._.js",
  "static/chunks/69652_@swc_helpers_cjs_77b72907._.js"
],
    source: "entry"
});
