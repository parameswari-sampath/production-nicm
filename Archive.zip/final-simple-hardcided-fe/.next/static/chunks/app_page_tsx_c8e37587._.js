(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_c49ac11a._.js",
  "static/chunks/_6e4e4f25._.js"
],
    source: "dynamic"
});
