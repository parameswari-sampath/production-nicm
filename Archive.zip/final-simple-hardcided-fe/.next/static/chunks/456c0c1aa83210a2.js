__turbopack_load_page_chunks__("/_app", [
  "static/chunks/577ea06e3adddf96.js",
  "static/chunks/8f487db0e2a413ca.js",
  "static/chunks/turbopack-e29f09ac7f021eb4.js"
])
