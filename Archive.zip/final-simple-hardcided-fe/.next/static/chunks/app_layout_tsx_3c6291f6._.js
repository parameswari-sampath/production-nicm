(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__91e7c569._.css",
  "static/chunks/node_modules__pnpm_55a88a38._.js",
  "static/chunks/_0aa415f7._.js"
],
    source: "dynamic"
});
