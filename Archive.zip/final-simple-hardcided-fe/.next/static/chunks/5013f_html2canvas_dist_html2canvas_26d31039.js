(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/5013f_html2canvas_dist_html2canvas_2bd6da66.js"
],
    source: "dynamic"
});
