(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_752896b8._.js",
  "static/chunks/node_modules__pnpm_d097ee0a._.js"
],
    source: "dynamic"
});
