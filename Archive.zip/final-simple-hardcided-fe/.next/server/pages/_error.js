var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/[root-of-the-server]__b6569061._.js")
R.c("server/chunks/ssr/[root-of-the-server]__02d47124._.js")
R.c("server/chunks/ssr/f7813_next_22d4c6b9._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/node_modules__pnpm_69ca5127._.js")
R.m(95895)
module.exports=R.m(95895).exports
