var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__74090862._.js")
R.m(32957)
module.exports=R.m(32957).exports
