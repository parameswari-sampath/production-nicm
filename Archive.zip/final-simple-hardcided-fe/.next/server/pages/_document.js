var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__b6569061._.js")
R.c("server/chunks/ssr/[root-of-the-server]__02d47124._.js")
R.m(57470)
module.exports=R.m(57470).exports
