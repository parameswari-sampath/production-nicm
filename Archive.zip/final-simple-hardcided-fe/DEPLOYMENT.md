# Docker Deployment Guide

## Prerequisites
- Docker installed on your system
- Docker Compose installed (optional, for easier deployment)

## Environment Variables

Create a `.env.production` file in the root directory with the following variables:

```env
NEXT_PUBLIC_API_BASE_URL=http://your-backend-url:8080
NEXT_PUBLIC_ADMIN_USERNAME=admin
NEXT_PUBLIC_ADMIN_PASSWORD=your-secure-password
JWT_SECRET_KEY=your-jwt-secret-key-min-32-chars
```

## Build and Run with Docker

### Option 1: Using Docker directly

1. **Build the Docker image:**
```bash
docker build -t smartmcq-frontend .
```

2. **Run the container:**
```bash
docker run -d \
  --name smartmcq-frontend \
  -p 3000:3000 \
  -e NEXT_PUBLIC_API_BASE_URL=http://localhost:8080 \
  -e NEXT_PUBLIC_ADMIN_USERNAME=admin \
  -e NEXT_PUBLIC_ADMIN_PASSWORD=admin123 \
  -e JWT_SECRET_KEY=your-secret-key-change-this-in-production-min-32-chars \
  smartmcq-frontend
```

3. **Access the application:**
Open your browser and navigate to `http://localhost:3000`

### Option 2: Using Docker Compose

1. **Start the application:**
```bash
docker-compose up -d
```

2. **View logs:**
```bash
docker-compose logs -f
```

3. **Stop the application:**
```bash
docker-compose down
```

## Commands

### View running containers
```bash
docker ps
```

### View container logs
```bash
docker logs smartmcq-frontend
```

### Stop the container
```bash
docker stop smartmcq-frontend
```

### Remove the container
```bash
docker rm smartmcq-frontend
```

### Rebuild the image
```bash
docker build --no-cache -t smartmcq-frontend .
```

## Production Deployment

For production deployment, make sure to:

1. Update environment variables with production values
2. Use a reverse proxy (nginx/traefik) for SSL termination
3. Set strong passwords for admin access
4. Configure proper CORS settings on your backend
5. Use proper JWT secret keys
6. Enable logging and monitoring

## Troubleshooting

### Container not starting
- Check logs: `docker logs smartmcq-frontend`
- Verify environment variables are set correctly
- Ensure port 3000 is not already in use

### Cannot connect to backend
- Verify `NEXT_PUBLIC_API_BASE_URL` points to the correct backend URL
- Check if backend is running and accessible
- Ensure network connectivity between containers (if using docker-compose)

### Build fails
- Clear Docker cache: `docker system prune -a`
- Check Node.js version compatibility
- Verify all dependencies are in package.json
